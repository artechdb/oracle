#!/bin/bash
################################################################################
# Oracle RAC Admin - Deployment Script
# Description: Deploys all necessary files to the target directory
################################################################################

set -e

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
NC='\033[0m' # No Color

# Target directory
TARGET_DIR="/u01/app/oracle/admin/scripts"
CONFIG_DIR="/u01/app/oracle/admin/config"

echo -e "${GREEN}+==============================================================================+${NC}"
echo -e "${GREEN}|              Oracle RAC Admin - Deployment Script                            |${NC}"
echo -e "${GREEN}+==============================================================================+${NC}"
echo ""

# Check if running as oracle user
if [[ "${USER}" != "oracle" ]]; then
    echo -e "${YELLOW}[WARNING] You are running as '${USER}', not 'oracle'${NC}"
    echo -e "${YELLOW}          It's recommended to run as oracle user${NC}"
    read -p "Continue anyway? (y/n): " continue_choice
    if [[ ! "${continue_choice}" =~ ^[Yy]$ ]]; then
        echo "Deployment cancelled"
        exit 1
    fi
fi

# Create directories
echo -e "${GREEN}[1/5] Creating directories...${NC}"
mkdir -p "${TARGET_DIR}"
mkdir -p "${CONFIG_DIR}"
mkdir -p "/u01/app/oracle/admin/logs"
mkdir -p "/u01/app/oracle/admin/reports"
echo "      ✓ Directories created"
echo ""

# Get source directory (where this script is located)
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Copy main script
echo -e "${GREEN}[2/5] Copying main script...${NC}"
if [[ -f "${SCRIPT_DIR}/oracle_rac_admin.sh" ]]; then
    cp "${SCRIPT_DIR}/oracle_rac_admin.sh" "${TARGET_DIR}/"
    chmod 750 "${TARGET_DIR}/oracle_rac_admin.sh"
    echo "      ✓ oracle_rac_admin.sh"
else
    echo -e "${RED}      ✗ oracle_rac_admin.sh NOT FOUND!${NC}"
    exit 1
fi
echo ""

# Copy function files
echo -e "${GREEN}[3/5] Copying function files...${NC}"
FUNCTION_FILES=(
    "functions_common.sh"
    "functions_db_health.sh"
    "functions_dg_health.sh"
    "functions_dg_switchover.sh"
    "functions_restore_point.sh"
)

for func_file in "${FUNCTION_FILES[@]}"; do
    if [[ -f "${SCRIPT_DIR}/${func_file}" ]]; then
        cp "${SCRIPT_DIR}/${func_file}" "${TARGET_DIR}/"
        chmod 640 "${TARGET_DIR}/${func_file}"
        echo "      ✓ ${func_file}"
    else
        echo -e "${RED}      ✗ ${func_file} NOT FOUND!${NC}"
        exit 1
    fi
done
echo ""

# Copy configuration file
echo -e "${GREEN}[4/5] Copying configuration file...${NC}"
if [[ -f "${SCRIPT_DIR}/oracle_admin.conf" ]]; then
    if [[ -f "${TARGET_DIR}/oracle_admin.conf" ]]; then
        # Backup existing config
        cp "${TARGET_DIR}/oracle_admin.conf" "${TARGET_DIR}/oracle_admin.conf.backup.$(date +%Y%m%d_%H%M%S)"
        echo "      ✓ Existing config backed up"
    fi
    cp "${SCRIPT_DIR}/oracle_admin.conf" "${TARGET_DIR}/"
    chmod 640 "${TARGET_DIR}/oracle_admin.conf"
    echo "      ✓ oracle_admin.conf"
else
    echo -e "${RED}      ✗ oracle_admin.conf NOT FOUND!${NC}"
    exit 1
fi
echo ""

# Copy database list
echo -e "${GREEN}[5/5] Copying database list...${NC}"
if [[ -f "${SCRIPT_DIR}/database_list.txt" ]]; then
    if [[ ! -f "${CONFIG_DIR}/database_list.txt" ]]; then
        cp "${SCRIPT_DIR}/database_list.txt" "${CONFIG_DIR}/"
        chmod 640 "${CONFIG_DIR}/database_list.txt"
        echo "      ✓ database_list.txt (new)"
    else
        echo "      ℹ database_list.txt already exists, keeping current version"
        echo "        (New version available at: ${SCRIPT_DIR}/database_list.txt)"
    fi
else
    echo -e "${YELLOW}      ⚠ database_list.txt NOT FOUND (optional)${NC}"
fi
echo ""

# Verify installation
echo -e "${GREEN}+==============================================================================+${NC}"
echo -e "${GREEN}|                         Verifying Installation                               |${NC}"
echo -e "${GREEN}+==============================================================================+${NC}"
echo ""

cd "${TARGET_DIR}"

# Check if all files exist
echo "Checking files..."
ALL_OK=true

FILES_TO_CHECK=(
    "oracle_rac_admin.sh"
    "functions_common.sh"
    "functions_db_health.sh"
    "functions_dg_health.sh"
    "functions_dg_switchover.sh"
    "functions_restore_point.sh"
    "oracle_admin.conf"
)

for file in "${FILES_TO_CHECK[@]}"; do
    if [[ -f "${TARGET_DIR}/${file}" ]]; then
        echo "  ✓ ${file}"
    else
        echo -e "  ${RED}✗ ${file}${NC}"
        ALL_OK=false
    fi
done

if [[ -f "${CONFIG_DIR}/database_list.txt" ]]; then
    echo "  ✓ ${CONFIG_DIR}/database_list.txt"
else
    echo -e "  ${YELLOW}⚠ ${CONFIG_DIR}/database_list.txt (you need to create this)${NC}"
fi

echo ""

# Test syntax
echo "Checking syntax..."
if bash -n oracle_rac_admin.sh 2>/dev/null; then
    echo "  ✓ oracle_rac_admin.sh syntax OK"
else
    echo -e "  ${RED}✗ oracle_rac_admin.sh syntax error${NC}"
    ALL_OK=false
fi

for func_file in "${FUNCTION_FILES[@]}"; do
    if bash -n "${func_file}" 2>/dev/null; then
        echo "  ✓ ${func_file} syntax OK"
    else
        echo -e "  ${RED}✗ ${func_file} syntax error${NC}"
        ALL_OK=false
    fi
done

echo ""

if [[ "${ALL_OK}" == "true" ]]; then
    echo -e "${GREEN}+==============================================================================+${NC}"
    echo -e "${GREEN}|                    ✓ DEPLOYMENT SUCCESSFUL!                                  |${NC}"
    echo -e "${GREEN}+==============================================================================+${NC}"
    echo ""
    echo "Installation directory: ${TARGET_DIR}"
    echo "Configuration file: ${TARGET_DIR}/oracle_admin.conf"
    echo "Database list: ${CONFIG_DIR}/database_list.txt"
    echo ""
    echo "To run the script:"
    echo "  cd ${TARGET_DIR}"
    echo "  ./oracle_rac_admin.sh"
    echo ""
    echo -e "${YELLOW}IMPORTANT: Edit the following before first use:${NC}"
    echo "  1. ${TARGET_DIR}/oracle_admin.conf"
    echo "     - Update SYS password"
    echo "     - Update email settings"
    echo "  2. ${CONFIG_DIR}/database_list.txt"
    echo "     - Add your databases"
    echo ""
else
    echo -e "${RED}+==============================================================================+${NC}"
    echo -e "${RED}|                    ✗ DEPLOYMENT FAILED!                                      |${NC}"
    echo -e "${RED}+==============================================================================+${NC}"
    echo ""
    echo "Please check the errors above and try again"
    exit 1
fi

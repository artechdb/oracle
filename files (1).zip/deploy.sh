#!/bin/bash

################################################################################
# Oracle RAC Admin Scripts - Quick Deployment Script
# Version: 2.1
# Date: November 14, 2025
################################################################################

echo ""
echo "======================================================================"
echo " Oracle RAC Administration Scripts - Quick Deployment"
echo " Version 2.1 - Comprehensive Fix"
echo "======================================================================"
echo ""

# Color codes
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Function to print colored messages
print_success() {
    echo -e "${GREEN}✓${NC} $1"
}

print_error() {
    echo -e "${RED}✗${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}!${NC} $1"
}

print_info() {
    echo -e "${BLUE}ℹ${NC} $1"
}

# Check if running from correct directory
if [[ ! -f "oracle_rac_admin.sh" ]]; then
    print_error "oracle_rac_admin.sh not found in current directory"
    echo ""
    echo "Please run this script from the directory containing the Oracle scripts"
    exit 1
fi

print_info "Deployment directory: $(pwd)"
echo ""

# Step 1: Backup existing scripts
echo "Step 1: Backing up existing scripts..."
echo "--------------------------------------"

BACKUP_DIR="backup_$(date +%Y%m%d_%H%M%S)"
mkdir -p "$BACKUP_DIR"

if ls oracle_rac_admin*.sh 2>/dev/null | grep -v "$(date +%Y%m%d)" &>/dev/null; then
    cp oracle_rac_admin*.sh "$BACKUP_DIR/" 2>/dev/null
    print_success "Backed up main scripts to $BACKUP_DIR/"
fi

if ls functions_*.sh 2>/dev/null; then
    cp functions_*.sh "$BACKUP_DIR/" 2>/dev/null
    print_success "Backed up function files to $BACKUP_DIR/"
fi

if [[ -d "config" ]]; then
    cp -r config "$BACKUP_DIR/" 2>/dev/null
    print_success "Backed up configuration files to $BACKUP_DIR/"
fi

echo ""

# Step 2: Verify all required files
echo "Step 2: Verifying required files..."
echo "------------------------------------"

required_files=(
    "oracle_rac_admin.sh"
    "functions_common.sh"
    "functions_db_health.sh"
    "functions_dg_health.sh"
    "functions_dg_switchover.sh"
    "functions_restore_point.sh"
)

missing_files=0
for file in "${required_files[@]}"; do
    if [[ -f "$file" ]]; then
        print_success "Found: $file"
    else
        print_error "Missing: $file"
        ((missing_files++))
    fi
done

if [[ $missing_files -gt 0 ]]; then
    echo ""
    print_error "$missing_files file(s) missing!"
    echo "Please ensure all required files are in the current directory"
    exit 1
fi

echo ""

# Step 3: Set executable permissions
echo "Step 3: Setting executable permissions..."
echo "------------------------------------------"

for file in "${required_files[@]}"; do
    chmod +x "$file"
    if [[ -x "$file" ]]; then
        print_success "Set executable: $file"
    else
        print_error "Failed to set executable: $file"
    fi
done

echo ""

# Step 4: Create required directories
echo "Step 4: Creating required directories..."
echo "-----------------------------------------"

directories=("config" "logs" "reports" "backups")

for dir in "${directories[@]}"; do
    if [[ ! -d "$dir" ]]; then
        mkdir -p "$dir"
        print_success "Created: $dir/"
    else
        print_info "Already exists: $dir/"
    fi
done

echo ""

# Step 5: Check configuration files
echo "Step 5: Checking configuration files..."
echo "----------------------------------------"

if [[ ! -f "config/database_list.txt" ]]; then
    print_warning "database_list.txt not found - creating template"
    cat > config/database_list.txt << 'EOF'
# Oracle RAC Database Configuration
# Format: DB_NAME|SCAN_HOST|SERVICE_NAME
#
# Examples:
# PRODDB|prod-scan.company.com|PRODDB_SVC
# TESTDB|test-scan.company.com|TESTDB_SVC

# Add your databases below:

EOF
    print_success "Created template: config/database_list.txt"
    print_warning "Please edit config/database_list.txt and add your databases"
else
    # Check if file has any valid entries
    valid_entries=$(grep -v "^#" config/database_list.txt | grep -v "^$" | wc -l)
    if [[ $valid_entries -gt 0 ]]; then
        print_success "Found $valid_entries database entries in database_list.txt"
    else
        print_warning "database_list.txt exists but has no valid entries"
        print_warning "Please add your database configurations"
    fi
fi

if [[ ! -f "config/script_config.conf" ]]; then
    print_warning "script_config.conf not found - creating template"
    cat > config/script_config.conf << 'EOF'
# Oracle Administration Configuration

# System User Credentials
SYS_USER="sys"
SYS_PASSWORD="change_me"

# Email Configuration
MAIL_ENABLED="NO"
MAIL_TO="dba@company.com"
MAIL_FROM="oracle_admin@company.com"

# Logging
ENABLE_AUDIT_LOG="YES"
LOG_RETENTION_DAYS=30

# Report Settings
REPORT_RETENTION_DAYS=90
EOF
    chmod 600 config/script_config.conf
    print_success "Created template: config/script_config.conf"
    print_warning "Please edit config/script_config.conf and set your credentials"
else
    print_success "Found: config/script_config.conf"
fi

echo ""

# Step 6: Syntax check
echo "Step 6: Performing syntax check..."
echo "-----------------------------------"

syntax_errors=0
for file in "${required_files[@]}"; do
    if bash -n "$file" 2>/dev/null; then
        print_success "Syntax OK: $file"
    else
        print_error "Syntax error in: $file"
        ((syntax_errors++))
    fi
done

if [[ $syntax_errors -gt 0 ]]; then
    echo ""
    print_error "Found syntax errors in $syntax_errors file(s)"
    echo "Please fix syntax errors before running"
    exit 1
fi

echo ""

# Step 7: Verify Oracle environment
echo "Step 7: Verifying Oracle environment..."
echo "----------------------------------------"

if [[ -z "$ORACLE_HOME" ]]; then
    print_error "ORACLE_HOME is not set"
    print_warning "Please set ORACLE_HOME before running the scripts"
else
    print_success "ORACLE_HOME: $ORACLE_HOME"
fi

if [[ -f "$ORACLE_HOME/bin/sqlplus" ]]; then
    print_success "Found: sqlplus"
else
    print_error "sqlplus not found in $ORACLE_HOME/bin"
fi

if command -v dgmgrl &> /dev/null; then
    print_success "Found: dgmgrl"
else
    print_warning "dgmgrl not found (only needed for Data Guard operations)"
fi

echo ""

# Step 8: Display deployment summary
echo "======================================================================"
echo " Deployment Summary"
echo "======================================================================"
echo ""

print_info "Backup Location:  $BACKUP_DIR/"
print_info "Script Location:  $(pwd)"
print_info "Configuration:    $(pwd)/config/"
print_info "Logs Directory:   $(pwd)/logs/"
print_info "Reports Directory: $(pwd)/reports/"

echo ""
echo "Files Deployed:"
for file in "${required_files[@]}"; do
    file_size=$(ls -lh "$file" | awk '{print $5}')
    printf "  %-35s %s\n" "$file" "$file_size"
done

echo ""
echo "======================================================================"

# Final checks and recommendations
echo ""
echo "Next Steps:"
echo ""

if [[ ! -f "config/database_list.txt" ]] || [[ $(grep -v "^#" config/database_list.txt | grep -v "^$" | wc -l) -eq 0 ]]; then
    echo "1. ⚠️  REQUIRED: Edit config/database_list.txt and add your databases"
    echo "   Format: DB_NAME|SCAN_HOST|SERVICE_NAME"
    echo ""
fi

if [[ -f "config/script_config.conf" ]]; then
    if grep -q "change_me" config/script_config.conf; then
        echo "2. ⚠️  REQUIRED: Edit config/script_config.conf and set credentials"
        echo "   Update SYS_PASSWORD with your actual password"
        echo ""
    fi
fi

echo "3. Test the deployment:"
echo "   ./oracle_rac_admin.sh"
echo ""

echo "4. Review the documentation:"
echo "   cat UPDATE_SUMMARY.md"
echo ""

# Final status
echo "======================================================================"
if [[ $syntax_errors -eq 0 ]] && [[ $missing_files -eq 0 ]]; then
    print_success "Deployment completed successfully!"
    echo ""
    echo "✅ All scripts are ready to use"
    echo "✅ Syntax validation passed"
    echo "✅ Required directories created"
    echo ""
    
    if [[ -n "$ORACLE_HOME" ]] && [[ -f "$ORACLE_HOME/bin/sqlplus" ]]; then
        echo "You can now run: ./oracle_rac_admin.sh"
    else
        print_warning "Please set up Oracle environment before running"
    fi
else
    print_error "Deployment completed with warnings"
    echo "Please address the issues above before running the scripts"
fi
echo "======================================================================"
echo ""

#!/bin/bash
################################################################################
# Oracle 19c RAC Database Health Check Functions
# Description: Functions for performing comprehensive database health checks
# Created: 2025-11-02
################################################################################

################################################################################
# Function: check_database_status
# Description: Checks overall database status and availability
# Parameters: $1 - Connection string
# Returns: HTML formatted status
################################################################################
check_database_status() {
    local conn_string=$1
    
    log_message "INFO" "Checking database status..."
    
    local output=$(${ORACLE_HOME}/bin/sqlplus -S "${conn_string}" << EOF
set heading off feedback off pagesize 0 linesize 200
select 
    instance_name || '|' || 
    host_name || '|' || 
    version || '|' || 
    status || '|' || 
    database_status || '|' ||
    to_char(startup_time, 'YYYY-MM-DD HH24:MI:SS') as info
from v\$instance;
exit;
EOF
)
    
    echo "${output}"
}

################################################################################
# Function: check_rac_instances
# Description: Checks status of all RAC instances
# Parameters: $1 - Connection string
# Returns: HTML table with RAC instance status
################################################################################
check_rac_instances() {
    local conn_string=$1
    
    log_message "INFO" "Checking RAC instances..."
    
    local output=$(${ORACLE_HOME}/bin/sqlplus -S "${conn_string}" << EOF
set heading on feedback off pagesize 1000 linesize 200
set markup html on
select 
    inst_id,
    instance_name,
    host_name,
    status,
    database_status,
    active_state,
    to_char(startup_time, 'YYYY-MM-DD HH24:MI:SS') as startup_time
from gv\$instance
order by inst_id;
exit;
EOF
)
    
    echo "${output}"
}

################################################################################
# Function: check_tablespace_usage
# Description: Checks tablespace usage and alerts on thresholds
# Parameters: $1 - Connection string
# Returns: HTML table with tablespace usage
################################################################################
check_tablespace_usage() {
    local conn_string=$1
    
    log_message "INFO" "Checking tablespace usage..."
    
    local output=$(${ORACLE_HOME}/bin/sqlplus -S "${conn_string}" << EOF
set heading on feedback off pagesize 1000 linesize 200
set markup html on
SELECT 
    tablespace_name,
    ROUND(total_mb, 2) as "TOTAL_MB",
    ROUND(used_mb, 2) as "USED_MB",
    ROUND(free_mb, 2) as "FREE_MB",
    ROUND(pct_used, 2) as "PCT_USED",
    CASE 
        WHEN pct_used >= ${TABLESPACE_CRITICAL_THRESHOLD} THEN 'CRITICAL'
        WHEN pct_used >= ${TABLESPACE_WARNING_THRESHOLD} THEN 'WARNING'
        ELSE 'OK'
    END as "STATUS"
FROM (
    SELECT 
        a.tablespace_name,
        a.bytes_alloc / 1024 / 1024 AS total_mb,
        NVL(b.bytes_used, 0) / 1024 / 1024 AS used_mb,
        (a.bytes_alloc - NVL(b.bytes_used, 0)) / 1024 / 1024 AS free_mb,
        (NVL(b.bytes_used, 0) / a.bytes_alloc) * 100 AS pct_used
    FROM (
        SELECT 
            tablespace_name,
            SUM(bytes) AS bytes_alloc
        FROM dba_data_files
        GROUP BY tablespace_name
    ) a,
    (
        SELECT 
            tablespace_name,
            SUM(bytes) AS bytes_used
        FROM dba_segments
        GROUP BY tablespace_name
    ) b
    WHERE a.tablespace_name = b.tablespace_name(+)
    UNION ALL
    SELECT 
        tablespace_name,
        SUM(bytes) / 1024 / 1024 AS total_mb,
        SUM(bytes) / 1024 / 1024 - SUM(maxbytes - bytes) / 1024 / 1024 AS used_mb,
        SUM(maxbytes - bytes) / 1024 / 1024 AS free_mb,
        ((SUM(bytes) / 1024 / 1024 - SUM(maxbytes - bytes) / 1024 / 1024) / (SUM(bytes) / 1024 / 1024)) * 100 AS pct_used
    FROM dba_temp_files
    GROUP BY tablespace_name
)
ORDER BY pct_used DESC;
exit;
EOF
)
    
    echo "${output}"
}

################################################################################
# Function: check_archive_log_status
# Description: Checks archive log generation and destination status
# Parameters: $1 - Connection string
# Returns: HTML formatted status
################################################################################
check_archive_log_status() {
    local conn_string=$1
    
    log_message "INFO" "Checking archive log status..."
    
    local output=$(${ORACLE_HOME}/bin/sqlplus -S "${conn_string}" << EOF
set heading on feedback off pagesize 1000 linesize 200
set markup html on
SELECT 
    dest_id,
    destination,
    status,
    error,
    log_sequence,
    archived_thread#
FROM v\$archive_dest
WHERE status != 'INACTIVE'
ORDER BY dest_id;
exit;
EOF
)
    
    echo "${output}"
}

################################################################################
# Function: check_database_size
# Description: Checks database size and growth
# Parameters: $1 - Connection string
# Returns: HTML formatted size information
################################################################################
check_database_size() {
    local conn_string=$1
    
    log_message "INFO" "Checking database size..."
    
    local output=$(${ORACLE_HOME}/bin/sqlplus -S "${conn_string}" << EOF
set heading on feedback off pagesize 1000 linesize 200
set markup html on
SELECT 
    'Data Files' as "TYPE",
    ROUND(SUM(bytes)/1024/1024/1024, 2) as "SIZE_GB"
FROM dba_data_files
UNION ALL
SELECT 
    'Temp Files' as "TYPE",
    ROUND(SUM(bytes)/1024/1024/1024, 2) as "SIZE_GB"
FROM dba_temp_files
UNION ALL
SELECT 
    'Redo Logs' as "TYPE",
    ROUND(SUM(bytes)/1024/1024/1024, 2) as "SIZE_GB"
FROM v\$log;
exit;
EOF
)
    
    echo "${output}"
}

################################################################################
# Function: check_invalid_objects
# Description: Checks for invalid database objects
# Parameters: $1 - Connection string
# Returns: HTML table with invalid objects
################################################################################
check_invalid_objects() {
    local conn_string=$1
    
    log_message "INFO" "Checking invalid objects..."
    
    local output=$(${ORACLE_HOME}/bin/sqlplus -S "${conn_string}" << EOF
set heading on feedback off pagesize 1000 linesize 200
set markup html on
SELECT 
    owner,
    object_type,
    COUNT(*) as "INVALID_COUNT"
FROM dba_objects
WHERE status = 'INVALID'
AND owner NOT IN ('SYS','SYSTEM','XDB','MDSYS','OLAPSYS','ORDSYS','OUTLN','WMSYS')
GROUP BY owner, object_type
ORDER BY COUNT(*) DESC;
exit;
EOF
)
    
    echo "${output}"
}

################################################################################
# Function: check_alert_log_errors
# Description: Checks for recent errors in alert log
# Parameters: $1 - Connection string
# Returns: HTML table with recent errors
################################################################################
check_alert_log_errors() {
    local conn_string=$1
    
    log_message "INFO" "Checking alert log for errors..."
    
    local output=$(${ORACLE_HOME}/bin/sqlplus -S "${conn_string}" << EOF
set heading on feedback off pagesize 1000 linesize 200
set markup html on
SELECT 
    originating_timestamp,
    message_text
FROM v\$diag_alert_ext
WHERE message_text LIKE '%ORA-%'
AND originating_timestamp > SYSDATE - 1
ORDER BY originating_timestamp DESC
FETCH FIRST 50 ROWS ONLY;
exit;
EOF
)
    
    echo "${output}"
}

################################################################################
# Function: check_asm_diskgroup_status
# Description: Checks ASM diskgroup status and usage
# Parameters: $1 - Connection string
# Returns: HTML table with ASM diskgroup status
################################################################################
check_asm_diskgroup_status() {
    local conn_string=$1
    
    log_message "INFO" "Checking ASM diskgroup status..."
    
    local output=$(${ORACLE_HOME}/bin/sqlplus -S "${conn_string}" << EOF
set heading on feedback off pagesize 1000 linesize 200
set markup html on
SELECT 
    name,
    state,
    type,
    ROUND(total_mb/1024, 2) as "TOTAL_GB",
    ROUND(free_mb/1024, 2) as "FREE_GB",
    ROUND((total_mb - free_mb)/1024, 2) as "USED_GB",
    ROUND(((total_mb - free_mb) / total_mb) * 100, 2) as "PCT_USED"
FROM v\$asm_diskgroup
ORDER BY name;
exit;
EOF
)
    
    echo "${output}"
}

################################################################################
# Function: check_cluster_interconnect
# Description: Checks cluster interconnect performance
# Parameters: $1 - Connection string
# Returns: HTML table with interconnect statistics
################################################################################
check_cluster_interconnect() {
    local conn_string=$1
    
    log_message "INFO" "Checking cluster interconnect..."
    
    local output=$(${ORACLE_HOME}/bin/sqlplus -S "${conn_string}" << EOF
set heading on feedback off pagesize 1000 linesize 200
set markup html on
SELECT 
    inst_id,
    name,
    ip_address,
    is_public,
    source
FROM gv\$cluster_interconnects
ORDER BY inst_id;
exit;
EOF
)
    
    echo "${output}"
}

################################################################################
# Function: check_active_sessions
# Description: Checks active database sessions
# Parameters: $1 - Connection string
# Returns: HTML table with session information
################################################################################
check_active_sessions() {
    local conn_string=$1
    
    log_message "INFO" "Checking active sessions..."
    
    local output=$(${ORACLE_HOME}/bin/sqlplus -S "${conn_string}" << EOF
set heading on feedback off pagesize 1000 linesize 200
set markup html on
SELECT 
    inst_id,
    status,
    COUNT(*) as "SESSION_COUNT"
FROM gv\$session
GROUP BY inst_id, status
ORDER BY inst_id, status;
exit;
EOF
)
    
    echo "${output}"
}

################################################################################
# Function: generate_database_health_report
# Description: Generates comprehensive database health check HTML report
# Parameters: $1 - Database name
#            $2 - SCAN hostname
#            $3 - Service name
################################################################################
generate_database_health_report() {
    local db_name=$1
    local scan_host=$2
    local service_name=$3
    local timestamp=$(date '+%Y%m%d_%H%M%S')
    local report_file="${REPORT_BASE_DIR}/${db_name}_health_check_${timestamp}.html"
    local connection_string="${SYS_USER}/${SYS_PASSWORD}@${scan_host}/${service_name} ${SYS_CONNECT_MODE}"
    
    log_message "INFO" "Generating database health check report for ${db_name}"
    
    # Test connection first
    if ! test_db_connection "${scan_host}" "${service_name}"; then
        log_message "ERROR" "Cannot connect to database ${db_name}"
        return 1
    fi
    
    # Generate HTML report
    {
        generate_html_header "Database Health Check Report - ${db_name}"
        
        echo "<h2>Database Information</h2>"
        local db_info=$(check_database_status "${connection_string}")
        IFS='|' read -r inst_name host_name version status db_status startup_time <<< "${db_info}"
        
        cat << EOF
        <table>
            <tr><th>Property</th><th>Value</th></tr>
            <tr><td>Instance Name</td><td>${inst_name}</td></tr>
            <tr><td>Host Name</td><td>${host_name}</td></tr>
            <tr><td>Version</td><td>${version}</td></tr>
            <tr><td>Status</td><td class="status-ok">${status}</td></tr>
            <tr><td>Database Status</td><td class="status-ok">${db_status}</td></tr>
            <tr><td>Startup Time</td><td>${startup_time}</td></tr>
        </table>
EOF
        
        echo "<h2>RAC Instance Status</h2>"
        check_rac_instances "${connection_string}"
        
        echo "<h2>Tablespace Usage</h2>"
        check_tablespace_usage "${connection_string}"
        
        echo "<h2>Database Size</h2>"
        check_database_size "${connection_string}"
        
        echo "<h2>Archive Log Status</h2>"
        check_archive_log_status "${connection_string}"
        
        echo "<h2>ASM Diskgroup Status</h2>"
        check_asm_diskgroup_status "${connection_string}"
        
        echo "<h2>Invalid Objects</h2>"
        check_invalid_objects "${connection_string}"
        
        echo "<h2>Cluster Interconnect</h2>"
        check_cluster_interconnect "${connection_string}"
        
        echo "<h2>Active Sessions Summary</h2>"
        check_active_sessions "${connection_string}"
        
        echo "<h2>Recent Alert Log Errors</h2>"
        check_alert_log_errors "${connection_string}"
        
        generate_html_footer
        
    } > "${report_file}"
    
    log_message "INFO" "Health check report generated: ${report_file}"
    
    # Send email
    send_email "Database Health Check - ${db_name}" "${report_file}"
    
    echo "${report_file}"
    return 0
}

################################################################################
# End of Database Health Check Functions
################################################################################

#!/bin/bash
################################################################################
# Oracle 19c RAC Database Administration - Common Utility Functions
# Description: Common utility functions used across all administration tasks
#              Includes integrated Data Guard common functions
# Created: 2025-11-02
# Updated: 2025-11-14 - DATABASE LOADING FIX + EMAIL FUNCTIONALITY
# Version: 2.1 Complete
################################################################################

################################################################################
# CRITICAL: Global Database Arrays - MUST BE DECLARED BEFORE ANY FUNCTIONS
# These arrays store loaded database configurations for menu display
################################################################################
declare -g -a DB_NAMES=()
declare -g -a DB_HOSTS=()
declare -g -a DB_SERVICES=()

# Global variables for selected database
declare -g SELECTED_DB_NAME=""
declare -g SELECTED_DB_HOST=""
declare -g SELECTED_DB_SERVICE=""

################################################################################
# LOGGING AND UTILITY FUNCTIONS
################################################################################

################################################################################
# Function: log_message
# Description: Logs messages with timestamp and log level
# Parameters: $1 - Log Level (INFO, WARN, ERROR, DEBUG)
#            $2 - Message
################################################################################
log_message() {
    local log_level=$1
    local message=$2
    local timestamp=$(date '+%Y-%m-%d %H:%M:%S')
    local log_file="${LOG_BASE_DIR}/oracle_admin_$(date '+%Y%m%d').log"
    
    # Create log directory if it doesn't exist
    mkdir -p "${LOG_BASE_DIR}"
    
    # Log message
    echo "[${timestamp}] [${log_level}] ${message}" >> "${log_file}"
    
    # Also print to console if not silent mode
    if [[ "${SILENT_MODE}" != "YES" ]]; then
        case ${log_level} in
            ERROR)
                echo -e "\033[0;31m[${timestamp}] [${log_level}] ${message}\033[0m"
                ;;
            WARN)
                echo -e "\033[0;33m[${timestamp}] [${log_level}] ${message}\033[0m"
                ;;
            INFO)
                echo -e "\033[0;32m[${timestamp}] [${log_level}] ${message}\033[0m"
                ;;
            *)
                echo "[${timestamp}] [${log_level}] ${message}"
                ;;
        esac
    fi
    
    # Audit logging
    if [[ "${ENABLE_AUDIT_LOG}" == "YES" ]] && [[ "${log_level}" == "ERROR" || "${log_level}" == "WARN" ]]; then
        echo "[${timestamp}] [${log_level}] [${USER}] ${message}" >> "${AUDIT_LOG_FILE}"
    fi
}

################################################################################
# Function: validate_prerequisites
# Description: Validates all prerequisites before executing any task
# Returns: 0 if success, 1 if failure
################################################################################
validate_prerequisites() {
    log_message "INFO" "Validating prerequisites..."
    
    # Check if Oracle Home is set
    if [[ -z "${ORACLE_HOME}" ]]; then
        log_message "ERROR" "ORACLE_HOME is not set"
        return 1
    fi
    
    # Check if Oracle binaries exist
    if [[ ! -f "${ORACLE_HOME}/bin/sqlplus" ]]; then
        log_message "ERROR" "sqlplus binary not found in ${ORACLE_HOME}/bin"
        return 1
    fi
    
    # Check if configuration file exists
    if [[ ! -f "${CONFIG_FILE}" ]]; then
        log_message "ERROR" "Configuration file not found: ${CONFIG_FILE}"
        return 1
    fi
    
    # Check if database list file exists
    if [[ ! -f "${DATABASE_LIST_FILE}" ]]; then
        log_message "ERROR" "Database list file not found: ${DATABASE_LIST_FILE}"
        return 1
    fi
    
    # Create required directories
    mkdir -p "${LOG_BASE_DIR}" "${REPORT_BASE_DIR}" "${BACKUP_DIR}"
    
    log_message "INFO" "Prerequisites validated successfully"
    return 0
}

################################################################################
# DATABASE CONNECTION AND VALIDATION FUNCTIONS
################################################################################

################################################################################
# Function: load_database_list
# Description: Loads database configuration from database_list.txt
# Parameters: $1 - Database name (or "ALL" for all databases)
# Returns: Database configuration line(s) in format: DB_NAME|SCAN|SERVICE
#          Empty if database not found
# Exit: Exits script if database not found or validation fails
################################################################################
load_database_list() {
    local db_name=$1
    
    log_message "INFO" "Loading database list for: ${db_name}"
    
    # Validate database list file exists and is readable
    if [[ ! -f "${DATABASE_LIST_FILE}" ]]; then
        log_message "ERROR" "Database list file not found: ${DATABASE_LIST_FILE}"
        echo ""
        return 1
    fi
    
    if [[ ! -r "${DATABASE_LIST_FILE}" ]]; then
        log_message "ERROR" "Database list file is not readable: ${DATABASE_LIST_FILE}"
        echo ""
        return 1
    fi
    
    # Check if file is empty
    if [[ ! -s "${DATABASE_LIST_FILE}" ]]; then
        log_message "ERROR" "Database list file is empty: ${DATABASE_LIST_FILE}"
        echo ""
        return 1
    fi
    
    local result=""
    local found=0
    
    # Read file line by line
    while IFS= read -r line || [[ -n "$line" ]]; do
        # Skip empty lines and comments
        [[ -z "$line" || "$line" =~ ^[[:space:]]*# ]] && continue
        
        # Validate line format (should have exactly 3 fields separated by |)
        local field_count=$(echo "$line" | awk -F'|' '{print NF}')
        if [[ $field_count -ne 3 ]]; then
            log_message "WARN" "Invalid line format (expected 3 fields): $line"
            continue
        fi
        
        # Parse the line
        IFS='|' read -r db scan service <<< "$line"
        
        # Trim whitespace
        db=$(echo "$db" | xargs)
        scan=$(echo "$scan" | xargs)
        service=$(echo "$service" | xargs)
        
        # Validate each field is not empty
        if [[ -z "$db" || -z "$scan" || -z "$service" ]]; then
            log_message "WARN" "Line has empty fields: $line"
            continue
        fi
        
        # Check if this is the database we're looking for or if we want all
        if [[ "${db_name}" == "ALL" ]] || [[ "${db}" == "${db_name}" ]]; then
            if [[ -n "$result" ]]; then
                result="${result}\n${db}|${scan}|${service}"
            else
                result="${db}|${scan}|${service}"
            fi
            found=1
            log_message "INFO" "Found database: ${db} -> ${scan}/${service}"
            
            # If looking for specific database, we can stop here
            if [[ "${db_name}" != "ALL" ]]; then
                break
            fi
        fi
    done < "${DATABASE_LIST_FILE}"
    
    # Check if we found any databases
    if [[ $found -eq 0 ]]; then
        if [[ "${db_name}" == "ALL" ]]; then
            log_message "ERROR" "No valid database entries found in ${DATABASE_LIST_FILE}"
        else
            log_message "ERROR" "Database '${db_name}' not found in ${DATABASE_LIST_FILE}"
        fi
        echo ""
        return 1
    fi
    
    # Return the result
    echo -e "$result"
    return 0
}

################################################################################
# Function: load_database_list_to_arrays
# Description: Load ALL databases from configuration file into global arrays
#              This function is for menu display and database selection
# Usage: load_database_list_to_arrays
# Returns: 0 on success, 1 on failure
# Populates: DB_NAMES[], DB_HOSTS[], DB_SERVICES[] global arrays
################################################################################
load_database_list_to_arrays() {
    local db_list_file="${DATABASE_LIST_FILE}"
    
    # Clear existing arrays
    DB_NAMES=()
    DB_HOSTS=()
    DB_SERVICES=()
    
    # Check if file exists
    if [[ ! -f "$db_list_file" ]]; then
        log_message "ERROR" "Database list file not found: $db_list_file"
        echo "ERROR: Database list file not found: $db_list_file"
        return 1
    fi
    
    # Check if file is readable
    if [[ ! -r "$db_list_file" ]]; then
        log_message "ERROR" "Database list file not readable: $db_list_file"
        echo "ERROR: Database list file not readable: $db_list_file"
        return 1
    fi
    
    log_message "INFO" "Loading database list into arrays from: $db_list_file"
    
    local line_num=0
    local valid_entries=0
    local skipped_lines=0
    
    # Read file line by line - preserve exact line content with IFS=
    while IFS= read -r line || [[ -n "$line" ]]; do
        ((line_num++))
        
        # Skip empty lines
        [[ -z "$line" ]] && continue
        
        # Skip comment lines
        [[ "$line" =~ ^[[:space:]]*# ]] && continue
        
        # Parse using awk for reliable field separation
        local db_name=$(echo "$line" | awk -F'|' '{print $1}' | xargs)
        local scan_host=$(echo "$line" | awk -F'|' '{print $2}' | xargs)
        local service_name=$(echo "$line" | awk -F'|' '{print $3}' | xargs)
        
        # Validate that all three fields are present and non-empty
        if [[ -z "$db_name" || -z "$scan_host" || -z "$service_name" ]]; then
            log_message "WARN" "Line $line_num: Incomplete entry (missing fields) - skipping: $line"
            ((skipped_lines++))
            continue
        fi
        
        # Validate field count (should be exactly 3 fields)
        local field_count=$(echo "$line" | awk -F'|' '{print NF}')
        if [[ $field_count -ne 3 ]]; then
            log_message "WARN" "Line $line_num: Invalid format (expected 3 fields, got $field_count) - skipping: $line"
            ((skipped_lines++))
            continue
        fi
        
        # Add to global arrays
        DB_NAMES+=("$db_name")
        DB_HOSTS+=("$scan_host")
        DB_SERVICES+=("$service_name")
        ((valid_entries++))
        
        log_message "DEBUG" "Loaded database entry $valid_entries: $db_name | $scan_host | $service_name"
        
    done < "$db_list_file"
    
    # Report results
    if [[ $valid_entries -eq 0 ]]; then
        log_message "ERROR" "No valid database entries found in $db_list_file"
        echo ""
        echo "ERROR: No valid database entries found!"
        echo "Please check the format of $db_list_file"
        echo "Expected format: DB_NAME|SCAN_HOST|SERVICE_NAME"
        echo ""
        return 1
    fi
    
    log_message "INFO" "Successfully loaded $valid_entries database entries from $db_list_file"
    
    if [[ $skipped_lines -gt 0 ]]; then
        log_message "WARN" "Skipped $skipped_lines invalid lines"
    fi
    
    return 0
}

################################################################################
# Function: display_database_menu
# Description: Display available databases in a menu format
# Usage: display_database_menu "Menu Title"
# Returns: 0 on success, 1 if no databases available
################################################################################
display_database_menu() {
    local title="${1:-Select Database}"
    
    # Check if databases are loaded
    if [[ ${#DB_NAMES[@]} -eq 0 ]]; then
        echo ""
        echo "ERROR: No databases available!"
        echo "Please check ${DATABASE_LIST_FILE}"
        echo ""
        return 1
    fi
    
    # Display menu header
    echo ""
    echo "=========================================="
    echo " $title"
    echo "=========================================="
    echo ""
    
    # Display databases
    for i in "${!DB_NAMES[@]}"; do
        printf "%2d) %-20s @ %-30s [%s]\n" \
            "$((i+1))" \
            "${DB_NAMES[$i]}" \
            "${DB_HOSTS[$i]}" \
            "${DB_SERVICES[$i]}"
    done
    
    echo " 0) Cancel"
    echo ""
    
    return 0
}

################################################################################
# Function: select_database_from_menu
# Description: Prompt user to select a database from the loaded arrays
# Usage: select_database_from_menu "Menu Title"
# Returns: Selected database index (0-based) in $? or 255 for cancel
################################################################################
select_database_from_menu() {
    local title="${1:-Select Database}"
    
    # Display the menu
    if ! display_database_menu "$title"; then
        return 255  # Menu display failed
    fi
    
    local choice
    read -p "Enter your choice [0-${#DB_NAMES[@]}]: " choice
    
    # Validate input is a number
    if ! [[ "$choice" =~ ^[0-9]+$ ]]; then
        echo ""
        echo "ERROR: Invalid input - please enter a number"
        echo ""
        return 255
    fi
    
    # Check for cancel (0)
    if [[ $choice -eq 0 ]]; then
        log_message "INFO" "User cancelled database selection"
        return 255
    fi
    
    # Convert menu choice to 0-based array index
    local index=$((choice - 1))
    
    # Validate index is within array bounds
    if [[ $index -lt 0 || $index -ge ${#DB_NAMES[@]} ]]; then
        echo ""
        echo "ERROR: Invalid selection"
        echo "Please choose a number between 1 and ${#DB_NAMES[@]}, or 0 to cancel"
        echo ""
        return 255
    fi
    
    # Valid selection
    log_message "INFO" "User selected database index $index: ${DB_NAMES[$index]}"
    return $index
}

################################################################################
# Function: get_database_info_by_index
# Description: Get database information by index and set global variables
# Usage: get_database_info_by_index <index>
# Sets: SELECTED_DB_NAME, SELECTED_DB_HOST, SELECTED_DB_SERVICE
# Returns: 0 on success, 1 on failure
################################################################################
get_database_info_by_index() {
    local index=$1
    
    # Validate index
    if [[ -z "$index" ]]; then
        log_message "ERROR" "get_database_info_by_index: No index provided"
        return 1
    fi
    
    if ! [[ "$index" =~ ^[0-9]+$ ]]; then
        log_message "ERROR" "get_database_info_by_index: Invalid index (not a number): $index"
        return 1
    fi
    
    if [[ $index -lt 0 || $index -ge ${#DB_NAMES[@]} ]]; then
        log_message "ERROR" "get_database_info_by_index: Index out of range: $index (valid: 0-$((${#DB_NAMES[@]} - 1)))"
        return 1
    fi
    
    # Set global variables
    SELECTED_DB_NAME="${DB_NAMES[$index]}"
    SELECTED_DB_HOST="${DB_HOSTS[$index]}"
    SELECTED_DB_SERVICE="${DB_SERVICES[$index]}"
    
    log_message "INFO" "Selected database: $SELECTED_DB_NAME @ $SELECTED_DB_HOST ($SELECTED_DB_SERVICE)"
    
    return 0
}

################################################################################
# Function: display_selected_database_info
# Description: Display information about the currently selected database
# Usage: display_selected_database_info
################################################################################
display_selected_database_info() {
    echo ""
    echo "Selected Database Information:"
    echo "  Database Name: $SELECTED_DB_NAME"
    echo "  SCAN Host:     $SELECTED_DB_HOST"
    echo "  Service Name:  $SELECTED_DB_SERVICE"
    echo ""
}

################################################################################
# Function: test_db_connection
# Description: Tests database connectivity using sqlplus
# Parameters: $1 - SCAN address
#            $2 - Service name
# Returns: 0 if connection successful, 1 if failed
# Output: Prints error message on failure
################################################################################
test_db_connection() {
    local scan=$1
    local service=$2
    local connection_string="${SYS_USER}/${SYS_PASSWORD}@${scan}/${service} as sysdba"
    
    log_message "INFO" "Testing database connection to ${scan}/${service}"
    
    # Mask password in logs
    local masked_conn="${SYS_USER}/***@${scan}/${service} as sysdba"
    log_message "DEBUG" "Connection string: ${masked_conn}"
    
    # Test connection
    local test_result=$(timeout ${CONNECTION_TIMEOUT:-30} ${ORACLE_HOME}/bin/sqlplus -S "${connection_string}" << EOF
whenever sqlerror exit 1
set heading off feedback off
select 'CONNECTION_SUCCESS' from dual;
exit;
EOF
)
    
    if echo "${test_result}" | grep -q "CONNECTION_SUCCESS"; then
        log_message "INFO" "Database connection successful"
        return 0
    else
        log_message "ERROR" "Database connection failed to ${scan}/${service}"
        log_message "ERROR" "Error details: ${test_result}"
        return 1
    fi
}

################################################################################
# Function: validate_database_connection
# Description: Validates database connection and exits if it fails
# Parameters: $1 - Database name
#            $2 - SCAN address
#            $3 - Service name
# Exit: Exits script with error code 1 if connection fails
################################################################################
validate_database_connection() {
    local db_name=$1
    local scan=$2
    local service=$3
    
    log_message "INFO" "Validating connection to database: ${db_name}"
    
    if ! test_db_connection "${scan}" "${service}"; then
        log_message "ERROR" "Cannot connect to database ${db_name}"
        log_message "ERROR" "SCAN: ${scan}, Service: ${service}"
        log_message "ERROR" "Script execution stopped due to connection failure"
        echo ""
        echo "================================================================"
        echo "          DATABASE CONNECTION VALIDATION FAILED"
        echo "================================================================"
        echo " Database: ${db_name}"
        echo " SCAN:     ${scan}"
        echo " Service:  ${service}"
        echo ""
        echo " Possible causes:"
        echo " 1. Database is down"
        echo " 2. Listener is not running"
        echo " 3. Network connectivity issues"
        echo " 4. Invalid credentials in configuration"
        echo " 5. Service name is incorrect"
        echo ""
        echo " Action: Fix the connection issue before retrying"
        echo "================================================================"
        echo ""
        exit 1
    fi
    
    log_message "INFO" "Database connection validated successfully: ${db_name}"
    return 0
}

################################################################################
# Function: get_db_role
# Description: Determines if database is PRIMARY or STANDBY
# Parameters: $1 - SCAN hostname
#            $2 - Service name
# Returns: Prints "PRIMARY" or "PHYSICAL STANDBY" or "UNKNOWN"
################################################################################
get_db_role() {
    local scan=$1
    local service=$2
    local connection_string="${SYS_USER}/${SYS_PASSWORD}@${scan}/${service} as sysdba"
    
    log_message "DEBUG" "Determining database role for ${scan}/${service}"
    
    local db_role=$(${ORACLE_HOME}/bin/sqlplus -S "${connection_string}" << EOF
whenever sqlerror exit 1
set heading off feedback off pagesize 0
select database_role from v\$database;
exit;
EOF
)
    
    db_role=$(echo "${db_role}" | xargs)
    
    if [[ "${db_role}" == "PRIMARY" ]] || [[ "${db_role}" == "PHYSICAL STANDBY" ]]; then
        echo "${db_role}"
        log_message "DEBUG" "Database role: ${db_role}"
        return 0
    else
        echo "UNKNOWN"
        log_message "ERROR" "Unable to determine database role"
        return 1
    fi
}

################################################################################
# EMAIL FUNCTIONS
################################################################################

################################################################################
# Function: send_email
# Description: Sends email with inline HTML content using mail/mailx
# Parameters: $1 - Subject
#            $2 - HTML content file path
#            $3 - Recipients (optional, uses default from config)
################################################################################
send_email() {
    local subject="$1"
    local html_file="$2"
    local recipients="${3:-$EMAIL_RECIPIENTS}"
    
    log_message "INFO" "Sending email: ${subject}"
    
    # Check if email is enabled
    if [[ "${MAIL_ENABLED}" != "YES" ]]; then
        log_message "INFO" "Email is disabled in configuration"
        return 0
    fi
    
    if [[ ! -f "${html_file}" ]]; then
        log_message "ERROR" "HTML file not found: ${html_file}"
        return 1
    fi
    
    # Check if recipients are configured
    if [[ -z "$recipients" ]]; then
        log_message "WARN" "No email recipients configured, skipping email"
        return 0
    fi
    
    # Check if mail or mailx is available
    local mail_cmd=""
    if command -v mailx &> /dev/null; then
        mail_cmd="mailx"
    elif command -v mail &> /dev/null; then
        mail_cmd="mail"
    else
        log_message "ERROR" "Neither mail nor mailx command is available"
        return 1
    fi
    
    log_message "DEBUG" "Using mail command: ${mail_cmd}"
    
    # Create a temporary file with proper MIME format
    local temp_email="/tmp/oracle_email_$$.txt"
    
    # Build proper MIME email
    cat > "${temp_email}" << EOF
From: ${EMAIL_FROM}
To: ${recipients}
Subject: ${EMAIL_SUBJECT_PREFIX} ${subject}
MIME-Version: 1.0
Content-Type: text/html; charset="UTF-8"
Content-Transfer-Encoding: 8bit

EOF
    
    # Append HTML content
    cat "${html_file}" >> "${temp_email}"
    
    # Send email using sendmail or mail -t
    local mail_result=1
    
    # Try sendmail first (most reliable for HTML)
    if command -v sendmail &> /dev/null; then
        log_message "DEBUG" "Using sendmail for delivery"
        sendmail -t < "${temp_email}"
        mail_result=$?
    else
        # Fallback to mail/mailx with -t flag
        log_message "DEBUG" "Using ${mail_cmd} -t for delivery"
        ${mail_cmd} -t < "${temp_email}"
        mail_result=$?
    fi
    
    # Cleanup
    rm -f "${temp_email}"
    
    if [[ ${mail_result} -eq 0 ]]; then
        log_message "INFO" "Email sent successfully to ${recipients}"
        return 0
    else
        log_message "ERROR" "Failed to send email (exit code: ${mail_result})"
        return 1
    fi
}

################################################################################
# HTML REPORT GENERATION FUNCTIONS
################################################################################

################################################################################
# Function: generate_html_header
# Description: Generates HTML header for reports
# Parameters: $1 - Report title
# Returns: HTML header content
################################################################################
generate_html_header() {
    local title="$1"
    local timestamp=$(date '+%Y-%m-%d %H:%M:%S')
    
    cat << EOF
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>${title}</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 20px;
            background-color: #f5f5f5;
        }
        .container {
            max-width: 1200px;
            margin: 0 auto;
            background-color: white;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        h1 {
            color: #c74634;
            border-bottom: 3px solid #c74634;
            padding-bottom: 10px;
        }
        h2 {
            color: #333;
            margin-top: 30px;
            border-left: 4px solid #c74634;
            padding-left: 10px;
        }
        h3 {
            color: #555;
            margin-top: 20px;
        }
        table {
            border-collapse: collapse;
            width: 100%;
            margin: 20px 0;
        }
        th {
            background-color: #c74634;
            color: white;
            padding: 12px;
            text-align: left;
        }
        td {
            border: 1px solid #ddd;
            padding: 10px;
        }
        tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        .status-ok {
            color: green;
            font-weight: bold;
        }
        .status-warning {
            color: orange;
            font-weight: bold;
        }
        .status-error {
            color: red;
            font-weight: bold;
        }
        .info-box {
            background-color: #e7f3fe;
            border-left: 6px solid #2196F3;
            padding: 10px;
            margin: 10px 0;
        }
        .warning-box {
            background-color: #fff3cd;
            border-left: 6px solid #ffc107;
            padding: 10px;
            margin: 10px 0;
        }
        .error-box {
            background-color: #f8d7da;
            border-left: 6px solid #dc3545;
            padding: 10px;
            margin: 10px 0;
        }
        .success-box {
            background-color: #d4edda;
            border-left: 6px solid #28a745;
            padding: 10px;
            margin: 10px 0;
        }
        .footer {
            margin-top: 40px;
            padding-top: 20px;
            border-top: 1px solid #ddd;
            text-align: center;
            color: #666;
            font-size: 12px;
        }
        pre {
            background-color: #f4f4f4;
            border: 1px solid #ddd;
            padding: 10px;
            overflow-x: auto;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>${title}</h1>
        <div class="info-box">
            <strong>Report Generated:</strong> ${timestamp}<br>
            <strong>Generated By:</strong> ${USER}@$(hostname)<br>
            <strong>Oracle Home:</strong> ${ORACLE_HOME}
        </div>
EOF
}

################################################################################
# Function: generate_html_footer
# Description: Generates HTML footer for reports
################################################################################
generate_html_footer() {
    cat << EOF
        <div class="footer">
            <p>Oracle 19c RAC Database Administration Report</p>
            <p>Generated by Oracle DBA Automation Script v2.1</p>
        </div>
    </div>
</body>
</html>
EOF
}

################################################################################
# UTILITY FUNCTIONS
################################################################################

################################################################################
# Function: cleanup_old_files
# Description: Cleans up old log and report files
# Parameters: $1 - Directory path
#            $2 - Retention days
################################################################################
cleanup_old_files() {
    local directory=$1
    local retention_days=$2
    
    log_message "INFO" "Cleaning up files older than ${retention_days} days in ${directory}"
    
    if [[ -d "${directory}" ]]; then
        local count=$(find "${directory}" -type f -mtime +${retention_days} | wc -l)
        find "${directory}" -type f -mtime +${retention_days} -delete
        log_message "INFO" "Cleanup completed - removed ${count} file(s)"
    else
        log_message "WARN" "Directory not found: ${directory}"
    fi
}

################################################################################
# Function: format_bytes
# Description: Formats bytes to human-readable format
# Parameters: $1 - Bytes value
################################################################################
format_bytes() {
    local bytes=$1
    
    if [[ $bytes -lt 1024 ]]; then
        echo "${bytes} B"
    elif [[ $bytes -lt 1048576 ]]; then
        echo "$(echo "scale=2; $bytes / 1024" | bc) KB"
    elif [[ $bytes -lt 1073741824 ]]; then
        echo "$(echo "scale=2; $bytes / 1048576" | bc) MB"
    else
        echo "$(echo "scale=2; $bytes / 1073741824" | bc) GB"
    fi
}

################################################################################
# Function: format_timestamp
# Description: Formats timestamp for display
# Parameters: $1 - Timestamp string
################################################################################
format_timestamp() {
    local timestamp=$1
    date -d "${timestamp}" '+%Y-%m-%d %H:%M:%S' 2>/dev/null || echo "${timestamp}"
}

################################################################################
# End of Common Utility Functions
################################################################################

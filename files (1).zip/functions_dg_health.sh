#!/bin/bash
################################################################################
# Oracle 19c Data Guard Health Check Functions - DGMGRL Based
# Description: Functions for Data Guard health checks using DGMGRL
# Version: 2.0
# Created: 2025-11-09
################################################################################

################################################################################
# Function: get_dg_broker_configuration
# Description: Gets Data Guard Broker configuration name and validates connection
# Parameters: $1 - Database name or SCAN/service from user selection
# Returns: DG_CONFIG_NAME (global variable)
#          DG_CONNECT_STRING (global variable)
################################################################################
get_dg_broker_configuration() {
    local db_name=$1
    
    log_message "INFO" "Checking for Data Guard Broker configuration..."
    
    # Get database connection details
    local selected_config=$(load_database_list "${db_name}")
    
    if [[ -z "${selected_config}" ]]; then
        log_message "ERROR" "Database '${db_name}' not found in configuration"
        return 1
    fi
    
    IFS='|' read -r db scan service <<< "${selected_config}"
    
    log_message "INFO" "Connecting to ${db} at ${scan}/${service}"
    
    # Test database connection
    if ! test_db_connection "${scan}" "${service}" 2>/dev/null; then
        log_message "ERROR" "Cannot connect to database ${db}"
        return 1
    fi
    
    # Build connection string for DGMGRL
    DG_CONNECT_STRING="${SYS_USER}/${SYS_PASSWORD}@${scan}/${service}"
    
    # Get Data Guard configuration name using DGMGRL
    local dg_config_output=$(${ORACLE_HOME}/bin/dgmgrl -silent << EOF
connect ${DG_CONNECT_STRING}
show configuration;
exit;
EOF
)
    
    # Check if connected to Data Guard configuration
    if echo "${dg_config_output}" | grep -qi "ORA-"; then
        log_message "ERROR" "Error connecting to Data Guard Broker"
        log_message "DEBUG" "DGMGRL output: ${dg_config_output}"
        return 1
    fi
    
    if echo "${dg_config_output}" | grep -qi "configuration does not exist"; then
        log_message "WARN" "Database is not part of Data Guard Broker configuration"
        return 1
    fi
    
    # Extract configuration name from "Configuration - <name>"
    DG_CONFIG_NAME=$(echo "${dg_config_output}" | grep -i "Configuration -" | sed 's/.*Configuration - \(.*\)/\1/' | xargs)
    
    if [[ -z "${DG_CONFIG_NAME}" ]]; then
        log_message "ERROR" "Could not determine Data Guard configuration name"
        return 1
    fi
    
    log_message "INFO" "Found Data Guard configuration: ${DG_CONFIG_NAME}"
    return 0
}

################################################################################
# Function: get_primary_database_dgmgrl
# Description: Gets primary database details from DGMGRL
# Returns: PRIMARY_DB_NAME, PRIMARY_DB_UNIQUE_NAME, PRIMARY_ROLE (global variables)
################################################################################
get_primary_database_dgmgrl() {
    log_message "INFO" "Identifying primary database from Data Guard configuration..."
    
    if [[ -z "${DG_CONNECT_STRING}" ]] || [[ -z "${DG_CONFIG_NAME}" ]]; then
        log_message "ERROR" "Data Guard configuration not initialized"
        return 1
    fi
    
    # Get configuration details from DGMGRL
    local dg_show_config=$(${ORACLE_HOME}/bin/dgmgrl -silent << EOF
connect ${DG_CONNECT_STRING}
show configuration verbose;
exit;
EOF
)
    
    # Find primary database line (format: "  Primary database is <db_unique_name>")
    local primary_line=$(echo "${dg_show_config}" | grep -i "Primary database" | head -1)
    
    if [[ -z "${primary_line}" ]]; then
        log_message "ERROR" "Could not identify primary database"
        return 1
    fi
    
    # Extract primary database unique name
    PRIMARY_DB_UNIQUE_NAME=$(echo "${primary_line}" | sed 's/.*Primary database is \(.*\)/\1/' | xargs)
    PRIMARY_ROLE="PRIMARY"
    
    log_message "INFO" "Primary database: ${PRIMARY_DB_UNIQUE_NAME}"
    
    # Get detailed info about primary
    local primary_details=$(${ORACLE_HOME}/bin/dgmgrl -silent << EOF
connect ${DG_CONNECT_STRING}
show database ${PRIMARY_DB_UNIQUE_NAME};
exit;
EOF
)
    
    # Store primary details for later use
    PRIMARY_DB_DETAILS="${primary_details}"
    
    return 0
}

################################################################################
# Function: get_all_standby_databases_dgmgrl
# Description: Gets all standby databases from DGMGRL
# Returns: STANDBY_DBS_ARRAY (array of db_unique_names)
################################################################################
get_all_standby_databases_dgmgrl() {
    log_message "INFO" "Getting all standby databases from Data Guard configuration..."
    
    if [[ -z "${DG_CONNECT_STRING}" ]] || [[ -z "${DG_CONFIG_NAME}" ]]; then
        log_message "ERROR" "Data Guard configuration not initialized"
        return 1
    fi
    
    # Get configuration details from DGMGRL
    local dg_show_config=$(${ORACLE_HOME}/bin/dgmgrl -silent << EOF
connect ${DG_CONNECT_STRING}
show configuration verbose;
exit;
EOF
)
    
    # Initialize array
    STANDBY_DBS_ARRAY=()
    
    # Find all standby database lines (format: "  STANDBY1 - Physical standby database")
    while IFS= read -r line; do
        if echo "${line}" | grep -qi "Physical standby database"; then
            # Extract database name from format: "  STANDBY1 - Physical standby database"
            local standby_db=$(echo "${line}" | sed 's/^[[:space:]]*\([^[:space:]]*\)[[:space:]]*-.*/\1/' | xargs)
            if [[ -n "${standby_db}" ]]; then
                STANDBY_DBS_ARRAY+=("${standby_db}")
                log_message "INFO" "Found standby: ${standby_db}"
            fi
        fi
    done <<< "${dg_show_config}"
    
    log_message "INFO" "Found ${#STANDBY_DBS_ARRAY[@]} standby database(s)"
    
    return 0
}

################################################################################
# Function: check_dg_status_dgmgrl
# Description: Checks overall Data Guard configuration status
# Returns: 0 if healthy, 1 if issues found
################################################################################
check_dg_status_dgmgrl() {
    log_message "INFO" "Checking Data Guard configuration status..."
    
    local dg_status=$(${ORACLE_HOME}/bin/dgmgrl -silent << EOF
connect ${DG_CONNECT_STRING}
show configuration;
exit;
EOF
)
    
    # Check for SUCCESS status
    local overall_status="UNKNOWN"
    if echo "${dg_status}" | grep -qi "SUCCESS"; then
        overall_status="SUCCESS"
    elif echo "${dg_status}" | grep -qi "WARNING"; then
        overall_status="WARNING"
    elif echo "${dg_status}" | grep -qi "ERROR"; then
        overall_status="ERROR"
    fi
    
    DG_OVERALL_STATUS="${overall_status}"
    DG_STATUS_OUTPUT="${dg_status}"
    
    log_message "INFO" "Data Guard configuration status: ${overall_status}"
    
    return 0
}

################################################################################
# Function: check_database_status_dgmgrl
# Description: Checks status of a specific database in DG configuration
# Parameters: $1 - Database unique name
# Returns: Database status details
################################################################################
check_database_status_dgmgrl() {
    local db_unique_name=$1
    
    log_message "INFO" "Checking status of database: ${db_unique_name}"
    
    local db_status=$(${ORACLE_HOME}/bin/dgmgrl -silent << EOF
connect ${DG_CONNECT_STRING}
show database ${db_unique_name};
exit;
EOF
)
    
    echo "${db_status}"
}

################################################################################
# Function: check_standby_lag_dgmgrl
# Description: Checks transport and apply lag for standby database
# Parameters: $1 - Standby database unique name
# Returns: LAG_TRANSPORT, LAG_APPLY (in global variables)
################################################################################
check_standby_lag_dgmgrl() {
    local standby_db=$1
    
    log_message "INFO" "Checking lag for standby: ${standby_db}"
    
    local db_status=$(check_database_status_dgmgrl "${standby_db}")
    
    # Extract transport lag (format: "Transport Lag:      0 seconds")
    LAG_TRANSPORT=$(echo "${db_status}" | grep -i "Transport Lag:" | sed 's/.*Transport Lag: *\(.*\)/\1/' | xargs)
    
    # Extract apply lag (format: "Apply Lag:          0 seconds")
    LAG_APPLY=$(echo "${db_status}" | grep -i "Apply Lag:" | sed 's/.*Apply Lag: *\(.*\)/\1/' | xargs)
    
    log_message "INFO" "  Transport Lag: ${LAG_TRANSPORT}"
    log_message "INFO" "  Apply Lag: ${LAG_APPLY}"
    
    return 0
}

################################################################################
# Function: get_database_property_dgmgrl
# Description: Gets a specific property value for a database
# Parameters: $1 - Database unique name
#            $2 - Property name
# Returns: Property value
################################################################################
get_database_property_dgmgrl() {
    local db_unique_name=$1
    local property_name=$2
    
    local property_value=$(${ORACLE_HOME}/bin/dgmgrl -silent << EOF
connect ${DG_CONNECT_STRING}
show database ${db_unique_name} ${property_name};
exit;
EOF
)
    
    # Extract value from output (format: "PropertyName = 'value'")
    local value=$(echo "${property_value}" | grep -i "${property_name}" | sed "s/.*= *'\(.*\)'.*/\1/" | xargs)
    
    echo "${value}"
}

################################################################################
# Function: validate_dgmgrl_connection
# Description: Validates DGMGRL can connect and configuration exists
# Parameters: $1 - Connection string
# Returns: 0 if valid, 1 if invalid
################################################################################
validate_dgmgrl_connection() {
    local conn_string=$1
    
    local test_output=$(${ORACLE_HOME}/bin/dgmgrl -silent << EOF
connect ${conn_string}
show configuration;
exit;
EOF
)
    
    if echo "${test_output}" | grep -qi "ORA-\|Error\|configuration does not exist"; then
        return 1
    fi
    
    return 0
}

################################################################################
# Function: generate_dg_health_report
# Description: Generates comprehensive DG health report using DGMGRL
# Parameters: $1 - Database name
# Returns: 0 if successful, 1 if failed
################################################################################
generate_dg_health_report() {
    local db_name=$1
    local timestamp=$(date '+%Y%m%d_%H%M%S')
    local report_file="${REPORT_BASE_DIR}/${db_name}_dg_health_${timestamp}.html"
    
    log_message "INFO" "Generating Data Guard health report for ${db_name}"
    
    # Step 1: Get Data Guard configuration
    if ! get_dg_broker_configuration "${db_name}"; then
        log_message "ERROR" "Failed to get Data Guard configuration"
        return 1
    fi
    
    # Step 2: Identify primary database
    if ! get_primary_database_dgmgrl; then
        log_message "ERROR" "Failed to identify primary database"
        return 1
    fi
    
    # Step 3: Get all standby databases
    if ! get_all_standby_databases_dgmgrl; then
        log_message "ERROR" "Failed to get standby databases"
        return 1
    fi
    
    # Step 4: Check overall DG status
    check_dg_status_dgmgrl
    
    # Step 5: Generate HTML report
    log_message "INFO" "Generating HTML report..."
    
    {
        generate_html_header "Data Guard Health Report - ${DG_CONFIG_NAME}"
        
        # Executive Summary Section
        echo "<h2>Executive Summary</h2>"
        cat << EOF
        <div style='background-color: #f0f8ff; padding: 15px; border-radius: 5px; border-left: 5px solid #007bff; margin-bottom: 20px;'>
            <h3 style='margin-top: 0;'>Data Guard Configuration: ${DG_CONFIG_NAME}</h3>
            <table style='width: 100%;'>
                <tr>
                    <td style='width: 50%;'><strong>Overall Status:</strong></td>
                    <td style='width: 50%;'><span style='font-size: 18px; font-weight: bold; color: $([ "${DG_OVERALL_STATUS}" = "SUCCESS" ] && echo "green" || echo "red");'>${DG_OVERALL_STATUS}</span></td>
                </tr>
                <tr>
                    <td><strong>Report Generated:</strong></td>
                    <td>$(date '+%Y-%m-%d %H:%M:%S')</td>
                </tr>
                <tr>
                    <td><strong>Primary Database:</strong></td>
                    <td><strong>${PRIMARY_DB_UNIQUE_NAME}</strong></td>
                </tr>
                <tr>
                    <td><strong>Standby Databases:</strong></td>
                    <td><strong>${#STANDBY_DBS_ARRAY[@]}</strong></td>
                </tr>
            </table>
        </div>
EOF

        # Standby Status Summary
        if [[ ${#STANDBY_DBS_ARRAY[@]} -gt 0 ]]; then
            echo "<h3>Standby Database Summary</h3>"
            echo "<table>"
            echo "<tr><th>Standby Database</th><th>Transport Lag</th><th>Apply Lag</th><th>Status</th></tr>"
            
            for standby_db in "${STANDBY_DBS_ARRAY[@]}"; do
                check_standby_lag_dgmgrl "${standby_db}"
                
                # Determine lag status color
                local transport_status="✓"
                local apply_status="✓"
                local transport_color="green"
                local apply_color="green"
                
                # Check if lag is high (> 30 seconds)
                if echo "${LAG_TRANSPORT}" | grep -qE "[1-9][0-9][0-9]+ seconds|[4-9][0-9] seconds|[3-9] minutes|[1-9]+ hours"; then
                    transport_status="⚠"
                    transport_color="orange"
                fi
                
                if echo "${LAG_APPLY}" | grep -qE "[1-9][0-9][0-9]+ seconds|[4-9][0-9] seconds|[3-9] minutes|[1-9]+ hours"; then
                    apply_status="⚠"
                    apply_color="orange"
                fi
                
                echo "<tr>"
                echo "<td><strong>${standby_db}</strong></td>"
                echo "<td style='color: ${transport_color};'>${transport_status} ${LAG_TRANSPORT}</td>"
                echo "<td style='color: ${apply_color};'>${apply_status} ${LAG_APPLY}</td>"
                echo "<td style='color: green;'>✓ Active</td>"
                echo "</tr>"
            done
            
            echo "</table>"
        fi
        
        echo "<hr style='margin: 30px 0;'>"
        
        # Detailed Configuration Summary
        echo "<h2>Configuration Details</h2>"
        cat << EOF
        <table>
            <tr><th>Property</th><th>Value</th></tr>
            <tr><td>Configuration Name</td><td><strong>${DG_CONFIG_NAME}</strong></td></tr>
            <tr><td>Report Time</td><td>$(date '+%Y-%m-%d %H:%M:%S')</td></tr>
            <tr><td>Primary Database</td><td><strong>${PRIMARY_DB_UNIQUE_NAME}</strong></td></tr>
            <tr><td>Number of Standbys</td><td><strong>${#STANDBY_DBS_ARRAY[@]}</strong></td></tr>
            <tr><td>Overall Status</td><td class="status-${DG_OVERALL_STATUS,,}"><strong>${DG_OVERALL_STATUS}</strong></td></tr>
        </table>
EOF
        
        # Configuration Status Detail
        echo "<h2>Configuration Status</h2>"
        echo "<pre style='background-color: #f5f5f5; padding: 15px; border-radius: 5px;'>"
        echo "${DG_STATUS_OUTPUT}"
        echo "</pre>"
        
        # Primary Database Details
        echo "<h2>Primary Database Details</h2>"
        echo "<h3>${PRIMARY_DB_UNIQUE_NAME}</h3>"
        
        local primary_full_status=$(check_database_status_dgmgrl "${PRIMARY_DB_UNIQUE_NAME}")
        echo "<pre style='background-color: #f5f5f5; padding: 15px; border-radius: 5px;'>"
        echo "${primary_full_status}"
        echo "</pre>"
        
        # Standby Databases Details
        if [[ ${#STANDBY_DBS_ARRAY[@]} -gt 0 ]]; then
            echo "<h2>Standby Databases Details</h2>"
            
            for standby_db in "${STANDBY_DBS_ARRAY[@]}"; do
                echo "<h3>${standby_db}</h3>"
                
                # Get standby status
                local standby_status=$(check_database_status_dgmgrl "${standby_db}")
                
                # Check lag
                check_standby_lag_dgmgrl "${standby_db}"
                
                # Display standby info
                cat << EOF
                <table>
                    <tr><th>Property</th><th>Value</th></tr>
                    <tr><td>Database Unique Name</td><td>${standby_db}</td></tr>
                    <tr><td>Transport Lag</td><td><strong>${LAG_TRANSPORT}</strong></td></tr>
                    <tr><td>Apply Lag</td><td><strong>${LAG_APPLY}</strong></td></tr>
                </table>
EOF
                
                echo "<pre style='background-color: #f5f5f5; padding: 15px; border-radius: 5px; margin-top: 10px;'>"
                echo "${standby_status}"
                echo "</pre>"
            done
        else
            echo "<p>No standby databases found.</p>"
        fi
        
        # Additional Health Checks
        echo "<h2>Additional Health Checks</h2>"
        
        # Check protection mode
        echo "<h3>Protection Mode</h3>"
        local protection_mode=$(get_database_property_dgmgrl "${PRIMARY_DB_UNIQUE_NAME}" "ProtectionMode")
        echo "<p><strong>Protection Mode:</strong> ${protection_mode}</p>"
        
        # Check fast start failover status
        echo "<h3>Fast Start Failover</h3>"
        local fsfo_status=$(${ORACLE_HOME}/bin/dgmgrl -silent << EOF
connect ${DG_CONNECT_STRING}
show fast_start failover;
exit;
EOF
)
        echo "<pre style='background-color: #f5f5f5; padding: 15px; border-radius: 5px;'>"
        echo "${fsfo_status}"
        echo "</pre>"
        
        generate_html_footer
        
    } > "${report_file}"
    
    log_message "INFO" "Data Guard health report generated: ${report_file}"
    
    # Send email if configured
    if [[ "${ENABLE_EMAIL}" == "YES" ]] && [[ -n "${EMAIL_RECIPIENTS}" ]]; then
        log_message "INFO" "Sending Data Guard health report via email..."
        
        # Create email subject with status
        local email_subject="Data Guard Health Check - ${DG_CONFIG_NAME} - Status: ${DG_OVERALL_STATUS}"
        
        if send_email "${email_subject}" "${report_file}"; then
            log_message "INFO" "Data Guard health report emailed successfully to ${EMAIL_RECIPIENTS}"
            echo "  ✓ Report emailed to: ${EMAIL_RECIPIENTS}"
        else
            log_message "ERROR" "Failed to email Data Guard health report"
            echo "  ✗ Failed to send email"
        fi
    else
        if [[ "${ENABLE_EMAIL}" != "YES" ]]; then
            log_message "INFO" "Email disabled (ENABLE_EMAIL=${ENABLE_EMAIL})"
            echo "  ℹ Email notifications are disabled"
        elif [[ -z "${EMAIL_RECIPIENTS}" ]]; then
            log_message "WARN" "Email enabled but no recipients configured"
            echo "  ⚠ No email recipients configured"
        fi
    fi
    
    echo ""
    echo "================================================================"
    echo " Data Guard Health Report Generated"
    echo "================================================================"
    echo " Configuration: ${DG_CONFIG_NAME}"
    echo " Primary: ${PRIMARY_DB_UNIQUE_NAME}"
    echo " Standbys: ${#STANDBY_DBS_ARRAY[@]}"
    echo " Status: ${DG_OVERALL_STATUS}"
    echo " Report: ${report_file}"
    echo "================================================================"
    echo ""
    
    return 0
}

################################################################################
# Export functions for use by main script
################################################################################
export -f get_dg_broker_configuration
export -f get_primary_database_dgmgrl
export -f get_all_standby_databases_dgmgrl
export -f check_dg_status_dgmgrl
export -f check_database_status_dgmgrl
export -f check_standby_lag_dgmgrl
export -f get_database_property_dgmgrl
export -f validate_dgmgrl_connection
export -f generate_dg_health_report

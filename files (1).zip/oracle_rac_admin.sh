#!/bin/bash

################################################################################
# Oracle 19c RAC Database Administration - Main Script
# Description: Main menu system for Oracle RAC administration
# Version: 2.1 - Complete Fix Applied
# Created: 2025-11-02
# Updated: 2025-11-14 - COMPREHENSIVE FIX APPLIED
################################################################################

################################################################################
# SCRIPT INITIALIZATION
################################################################################

# Get script directory
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SCRIPT_NAME=$(basename "$0")

# Set configuration file paths
CONFIG_FILE="${SCRIPT_DIR}/config/script_config.conf"
DATABASE_LIST_FILE="${SCRIPT_DIR}/config/database_list.txt"

# Set directory paths
LOG_BASE_DIR="${SCRIPT_DIR}/logs"
REPORT_BASE_DIR="${SCRIPT_DIR}/reports"
BACKUP_DIR="${SCRIPT_DIR}/backups"

# Create directories if they don't exist
mkdir -p "${LOG_BASE_DIR}" "${REPORT_BASE_DIR}" "${BACKUP_DIR}" "${SCRIPT_DIR}/config"

# Source common functions library
if [[ -f "${SCRIPT_DIR}/functions_common.sh" ]]; then
    source "${SCRIPT_DIR}/functions_common.sh"
else
    echo "ERROR: functions_common.sh not found in ${SCRIPT_DIR}"
    echo "Please ensure the common functions library exists"
    exit 1
fi

# Source function modules
for func_file in "${SCRIPT_DIR}"/functions_*.sh; do
    if [[ -f "$func_file" ]] && [[ "$func_file" != *"functions_common.sh" ]]; then
        source "$func_file"
        echo "Loaded: $(basename "$func_file")"
    fi
done

################################################################################
# INITIALIZATION - LOAD DATABASE LIST INTO ARRAYS
################################################################################

# Load all databases into global arrays for menu display
echo ""
echo "Initializing Oracle RAC Administration System..."
echo "Loading database configuration..."
echo ""

if ! load_database_list_to_arrays; then
    echo ""
    echo "==============================================="
    echo "CRITICAL ERROR: Failed to load database list!"
    echo "==============================================="
    echo ""
    echo "Please check:"
    echo "  1. File exists: ${DATABASE_LIST_FILE}"
    echo "  2. File is readable"
    echo "  3. File has valid entries in format: DB_NAME|SCAN_HOST|SERVICE_NAME"
    echo ""
    echo "Example format:"
    echo "  PRODDB|prod-scan.company.com|PRODDB_SVC"
    echo "  TESTDB|test-scan.company.com|TESTDB_SVC"
    echo ""
    exit 1
fi

echo "✓ Successfully loaded ${#DB_NAMES[@]} database(s)"
echo ""

################################################################################
# MAIN MENU DISPLAY
################################################################################

display_main_menu() {
    clear
    echo "=========================================="
    echo "Oracle 19c RAC Administration System"
    echo "Version 2.1 - Complete Fix Applied"
    echo "=========================================="
    echo ""
    echo "Available Databases:"
    
    # Display loaded databases from arrays
    if [[ ${#DB_NAMES[@]} -eq 0 ]]; then
        echo "  WARNING: No databases loaded!"
        echo "  Please check ${DATABASE_LIST_FILE}"
    else
        for i in "${!DB_NAMES[@]}"; do
            printf "  %2d. %-15s @ %-30s [%s]\n" "$((i+1))" "${DB_NAMES[$i]}" "${DB_HOSTS[$i]}" "${DB_SERVICES[$i]}"
        done
    fi
    
    echo ""
    echo "=========================================="
    echo "Main Menu Options"
    echo "=========================================="
    echo " 1. Database Health Check"
    echo " 2. Data Guard Status"
    echo " 3. Data Guard Switchover"
    echo " 4. Restore Point Management"
    echo " 5. View All Databases"
    echo " 6. Reload Database List"
    echo " 7. View Logs"
    echo " 0. Exit"
    echo "=========================================="
    echo ""
}

################################################################################
# MENU OPTION HANDLERS
################################################################################

################################################################################
# Option 1: Database Health Check
################################################################################
handle_database_health_check() {
    clear
    echo "=========================================="
    echo "Database Health Check"
    echo "=========================================="
    echo ""
    
    # Select database from menu
    select_database_from_menu "Select Database for Health Check"
    local db_index=$?
    
    # Check if user cancelled (returns 255)
    if [[ $db_index -eq 255 ]]; then
        echo "Operation cancelled."
        read -p "Press Enter to continue..."
        return
    fi
    
    # Get database info by index
    if ! get_database_info_by_index "$db_index"; then
        echo "ERROR: Failed to get database information"
        read -p "Press Enter to continue..."
        return
    fi
    
    # Display selected database info
    display_selected_database_info
    
    # Confirm operation
    read -p "Proceed with health check? (yes/no): " confirm
    if [[ ! "$confirm" =~ ^[Yy][Ee]?[Ss]?$ ]]; then
        echo "Operation cancelled."
        read -p "Press Enter to continue..."
        return
    fi
    
    # Source the health check functions if not already loaded
    if [[ -f "${SCRIPT_DIR}/functions_db_health.sh" ]]; then
        source "${SCRIPT_DIR}/functions_db_health.sh"
    else
        echo "ERROR: functions_db_health.sh not found"
        read -p "Press Enter to continue..."
        return
    fi
    
    # Perform health check
    echo ""
    echo "Performing health check..."
    echo ""
    
    if perform_db_health_check "$SELECTED_DB_NAME" "$SELECTED_DB_HOST" "$SELECTED_DB_SERVICE"; then
        echo ""
        echo "✓ Health check completed successfully"
    else
        echo ""
        echo "✗ Health check failed or completed with errors"
    fi
    
    echo ""
    read -p "Press Enter to continue..."
}

################################################################################
# Option 2: Data Guard Status
################################################################################
handle_data_guard_status() {
    clear
    echo "=========================================="
    echo "Data Guard Status Check"
    echo "=========================================="
    echo ""
    
    # Select database from menu
    select_database_from_menu "Select Database for Data Guard Status"
    local db_index=$?
    
    # Check if user cancelled
    if [[ $db_index -eq 255 ]]; then
        echo "Operation cancelled."
        read -p "Press Enter to continue..."
        return
    fi
    
    # Get database info
    if ! get_database_info_by_index "$db_index"; then
        echo "ERROR: Failed to get database information"
        read -p "Press Enter to continue..."
        return
    fi
    
    # Display selected database info
    display_selected_database_info
    
    # Source DG health functions if not already loaded
    if [[ -f "${SCRIPT_DIR}/functions_dg_health.sh" ]]; then
        source "${SCRIPT_DIR}/functions_dg_health.sh"
    else
        echo "ERROR: functions_dg_health.sh not found"
        read -p "Press Enter to continue..."
        return
    fi
    
    # Perform Data Guard status check
    echo ""
    echo "Checking Data Guard status..."
    echo ""
    
    if perform_dg_health_check "$SELECTED_DB_NAME" "$SELECTED_DB_HOST" "$SELECTED_DB_SERVICE"; then
        echo ""
        echo "✓ Data Guard status check completed"
    else
        echo ""
        echo "✗ Data Guard status check failed"
    fi
    
    echo ""
    read -p "Press Enter to continue..."
}

################################################################################
# Option 3: Data Guard Switchover
################################################################################
handle_data_guard_switchover() {
    clear
    echo "=========================================="
    echo "Data Guard Switchover"
    echo "=========================================="
    echo ""
    echo "WARNING: This operation will switch database roles"
    echo "         Primary will become Standby and vice versa"
    echo ""
    
    # Select primary database
    echo "Step 1: Select CURRENT PRIMARY database"
    echo ""
    select_database_from_menu "Select Current Primary Database"
    local primary_index=$?
    
    if [[ $primary_index -eq 255 ]]; then
        echo "Operation cancelled."
        read -p "Press Enter to continue..."
        return
    fi
    
    # Get primary database info
    if ! get_database_info_by_index "$primary_index"; then
        echo "ERROR: Failed to get primary database information"
        read -p "Press Enter to continue..."
        return
    fi
    
    local primary_db="$SELECTED_DB_NAME"
    local primary_host="$SELECTED_DB_HOST"
    local primary_service="$SELECTED_DB_SERVICE"
    
    echo ""
    echo "Primary Database Selected:"
    echo "  Database: $primary_db"
    echo "  Host:     $primary_host"
    echo "  Service:  $primary_service"
    echo ""
    
    # Select standby database
    echo "Step 2: Select TARGET STANDBY database"
    echo ""
    select_database_from_menu "Select Target Standby Database"
    local standby_index=$?
    
    if [[ $standby_index -eq 255 ]]; then
        echo "Operation cancelled."
        read -p "Press Enter to continue..."
        return
    fi
    
    # Validate not selecting the same database
    if [[ $standby_index -eq $primary_index ]]; then
        echo ""
        echo "ERROR: Primary and Standby cannot be the same database!"
        read -p "Press Enter to continue..."
        return
    fi
    
    # Get standby database info
    if ! get_database_info_by_index "$standby_index"; then
        echo "ERROR: Failed to get standby database information"
        read -p "Press Enter to continue..."
        return
    fi
    
    local standby_db="$SELECTED_DB_NAME"
    local standby_host="$SELECTED_DB_HOST"
    local standby_service="$SELECTED_DB_SERVICE"
    
    echo ""
    echo "Standby Database Selected:"
    echo "  Database: $standby_db"
    echo "  Host:     $standby_host"
    echo "  Service:  $standby_service"
    echo ""
    
    # Display switchover plan
    echo "=========================================="
    echo "SWITCHOVER PLAN"
    echo "=========================================="
    echo "Current Primary: $primary_db @ $primary_host"
    echo "Current Standby: $standby_db @ $standby_host"
    echo ""
    echo "After Switchover:"
    echo "  New Primary: $standby_db @ $standby_host"
    echo "  New Standby: $primary_db @ $primary_host"
    echo "=========================================="
    echo ""
    
    # Final confirmation
    read -p "Type 'SWITCHOVER' to confirm this operation: " confirm
    if [[ "$confirm" != "SWITCHOVER" ]]; then
        echo "Operation cancelled."
        read -p "Press Enter to continue..."
        return
    fi
    
    # Source switchover functions
    if [[ -f "${SCRIPT_DIR}/functions_dg_switchover.sh" ]]; then
        source "${SCRIPT_DIR}/functions_dg_switchover.sh"
    else
        echo "ERROR: functions_dg_switchover.sh not found"
        read -p "Press Enter to continue..."
        return
    fi
    
    # Perform switchover
    echo ""
    echo "Initiating Data Guard switchover..."
    echo ""
    
    if perform_dg_switchover "$primary_db" "$primary_host" "$primary_service" "$standby_db" "$standby_host" "$standby_service"; then
        echo ""
        echo "✓ Switchover completed successfully"
    else
        echo ""
        echo "✗ Switchover failed or rolled back"
    fi
    
    echo ""
    read -p "Press Enter to continue..."
}

################################################################################
# Option 4: Restore Point Management
################################################################################
handle_restore_point_management() {
    clear
    echo "=========================================="
    echo "Restore Point Management"
    echo "=========================================="
    echo ""
    
    # Select database
    select_database_from_menu "Select Database for Restore Point Management"
    local db_index=$?
    
    if [[ $db_index -eq 255 ]]; then
        echo "Operation cancelled."
        read -p "Press Enter to continue..."
        return
    fi
    
    # Get database info
    if ! get_database_info_by_index "$db_index"; then
        echo "ERROR: Failed to get database information"
        read -p "Press Enter to continue..."
        return
    fi
    
    # Display selected database info
    display_selected_database_info
    
    # Source restore point functions
    if [[ -f "${SCRIPT_DIR}/functions_restore_point.sh" ]]; then
        source "${SCRIPT_DIR}/functions_restore_point.sh"
    else
        echo "ERROR: functions_restore_point.sh not found"
        read -p "Press Enter to continue..."
        return
    fi
    
    # Call the restore point menu
    manage_restore_points "$SELECTED_DB_NAME" "$SELECTED_DB_HOST" "$SELECTED_DB_SERVICE"
    
    echo ""
    read -p "Press Enter to continue..."
}

################################################################################
# Option 5: View All Databases
################################################################################
handle_view_all_databases() {
    clear
    echo "=========================================="
    echo "All Configured Databases"
    echo "=========================================="
    echo ""
    
    if [[ ${#DB_NAMES[@]} -eq 0 ]]; then
        echo "No databases configured."
        echo "Please add databases to: ${DATABASE_LIST_FILE}"
    else
        printf "%-4s %-20s %-35s %-25s\n" "No." "Database Name" "SCAN Host" "Service Name"
        echo "--------------------------------------------------------------------------------------------"
        
        for i in "${!DB_NAMES[@]}"; do
            printf "%-4d %-20s %-35s %-25s\n" "$((i+1))" "${DB_NAMES[$i]}" "${DB_HOSTS[$i]}" "${DB_SERVICES[$i]}"
        done
    fi
    
    echo ""
    echo "Total: ${#DB_NAMES[@]} database(s)"
    echo ""
    echo "Configuration file: ${DATABASE_LIST_FILE}"
    echo ""
    read -p "Press Enter to continue..."
}

################################################################################
# Option 6: Reload Database List
################################################################################
handle_reload_database_list() {
    clear
    echo "=========================================="
    echo "Reload Database List"
    echo "=========================================="
    echo ""
    echo "Current databases loaded: ${#DB_NAMES[@]}"
    echo ""
    read -p "Reload database list from configuration file? (yes/no): " confirm
    
    if [[ ! "$confirm" =~ ^[Yy][Ee]?[Ss]?$ ]]; then
        echo "Operation cancelled."
        read -p "Press Enter to continue..."
        return
    fi
    
    echo ""
    echo "Reloading database list..."
    echo ""
    
    if load_database_list_to_arrays; then
        echo ""
        echo "✓ Successfully reloaded ${#DB_NAMES[@]} database(s)"
        
        # Display reloaded databases
        echo ""
        echo "Reloaded Databases:"
        for i in "${!DB_NAMES[@]}"; do
            printf "  %2d. %-15s @ %-30s [%s]\n" "$((i+1))" "${DB_NAMES[$i]}" "${DB_HOSTS[$i]}" "${DB_SERVICES[$i]}"
        done
    else
        echo ""
        echo "✗ Failed to reload database list"
        echo "Please check ${DATABASE_LIST_FILE}"
    fi
    
    echo ""
    read -p "Press Enter to continue..."
}

################################################################################
# Option 7: View Logs
################################################################################
handle_view_logs() {
    clear
    echo "=========================================="
    echo "View Logs"
    echo "=========================================="
    echo ""
    
    # Find today's log file
    local today_log="${LOG_BASE_DIR}/oracle_admin_$(date '+%Y%m%d').log"
    
    if [[ ! -f "$today_log" ]]; then
        echo "No log file found for today: $today_log"
        echo ""
        echo "Available log files:"
        ls -lh "${LOG_BASE_DIR}"/oracle_admin_*.log 2>/dev/null || echo "  No log files found"
    else
        echo "Displaying last 50 lines of today's log:"
        echo "Log file: $today_log"
        echo ""
        echo "----------------------------------------"
        tail -50 "$today_log"
        echo "----------------------------------------"
    fi
    
    echo ""
    read -p "Press Enter to continue..."
}

################################################################################
# MAIN PROGRAM LOOP
################################################################################

main() {
    # Validate prerequisites
    if ! validate_prerequisites; then
        echo "ERROR: Prerequisites validation failed"
        exit 1
    fi
    
    # Main loop
    while true; do
        display_main_menu
        
        read -p "Select option: " choice
        
        case $choice in
            1)
                handle_database_health_check
                ;;
            2)
                handle_data_guard_status
                ;;
            3)
                handle_data_guard_switchover
                ;;
            4)
                handle_restore_point_management
                ;;
            5)
                handle_view_all_databases
                ;;
            6)
                handle_reload_database_list
                ;;
            7)
                handle_view_logs
                ;;
            0)
                clear
                echo ""
                echo "Exiting Oracle RAC Administration System..."
                echo "Goodbye!"
                echo ""
                exit 0
                ;;
            *)
                echo ""
                echo "Invalid option. Please try again."
                sleep 2
                ;;
        esac
    done
}

# Start the program
main

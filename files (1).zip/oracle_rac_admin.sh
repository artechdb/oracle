#!/bin/bash
################################################################################
# Oracle 19c RAC Database Administration - Main Script
# Description: Interactive menu-driven script for Oracle RAC database administration
# Version: 1.0
# Created: 2025-11-02
# Usage: ./oracle_rac_admin.sh
################################################################################

# Strict error handling
set -o pipefail

# Script directory
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Source configuration file
CONFIG_FILE="${SCRIPT_DIR}/oracle_admin.conf"
if [[ ! -f "${CONFIG_FILE}" ]]; then
    echo "ERROR: Configuration file not found: ${CONFIG_FILE}"
    exit 1
fi

source "${CONFIG_FILE}"

# Source function files
FUNCTION_FILES=(
    "${SCRIPT_DIR}/functions_common.sh"
    "${SCRIPT_DIR}/functions_db_health.sh"
    "${SCRIPT_DIR}/functions_dg_health.sh"
    "${SCRIPT_DIR}/functions_dg_switchover.sh"
    "${SCRIPT_DIR}/functions_restore_point.sh"
)

for func_file in "${FUNCTION_FILES[@]}"; do
    if [[ ! -f "${func_file}" ]]; then
        echo "ERROR: Function file not found: ${func_file}"
        exit 1
    fi
    source "${func_file}"
done

################################################################################
# Function: display_banner
# Description: Displays the application banner
################################################################################
display_banner() {
    echo "[DEBUG BANNER 1] About to clear screen"
    clear
    echo "[DEBUG BANNER 2] Screen cleared, about to show banner"
    cat << "EOF"
+==============================================================================+
|                                                                              |
|          ######+ ######+  #####+  ######+##+     #######+                  |
|         ##+===##+##+==##+##+==##+##+====+##|     ##+====+                  |
|         ##|   ##|######++#######|##|     ##|     #####+                    |
|         ##|   ##|##+==##+##+==##|##|     ##|     ##+==+                    |
|         +######++##|  ##|##|  ##|+######+#######+#######+                  |
|          +=====+ +=+  +=++=+  +=+ +=====++======++======+                  |
|                                                                              |
|              Oracle 19c RAC Database Administration System                   |
|                          Version 1.0                                         |
|                                                                              |
+==============================================================================+

EOF
    echo "Current User: ${USER}@$(hostname)"
    echo "Current Time: $(date '+%Y-%m-%d %H:%M:%S')"
    echo "Oracle Home: ${ORACLE_HOME}"
    echo ""
}

################################################################################
# Function: display_main_menu
# Description: Displays the main menu
################################################################################
display_main_menu() {
    echo "+==============================================================+"
    echo "|                        MAIN MENU                             |"
    echo "+==============================================================+"
    echo "|  1) Database Health Check                                    |"
    echo "|  2) Data Guard Health Check                                  |"
    echo "|  3) Data Guard Switchover                                    |"
    echo "|  4) Restore Point Management                                 |"
    echo "|  5) System Configuration                                     |"
    echo "|  6) View Logs                                                |"
    echo "|  7) Cleanup Old Reports                                      |"
    echo "|  0) Exit                                                     |"
    echo "+==============================================================+"
    echo ""
}

################################################################################
# Function: prompt_manual_database_input
# Description: Prompts user to manually enter database details
# Parameters: $1 - Optional pre-filled database name
# Returns: DB_NAME|SCAN_HOST|SERVICE_NAME or empty if cancelled
################################################################################
prompt_manual_database_input() {
    local prefill_input="${1:-}"
    
    # Extract just the database name if full format was passed
    local prefill_db_name=""
    if [[ "${prefill_input}" == *"|"* ]]; then
        # Extract DB name from DB_NAME|SCAN|SERVICE format
        IFS='|' read -r prefill_db_name _ _ <<< "${prefill_input}"
    else
        prefill_db_name="${prefill_input}"
    fi
    
    echo ""
    echo "================================================================"
    echo " Manual Database Input"
    echo "================================================================"
    
    local manual_db_name="${prefill_db_name}"
    local manual_scan=""
    local manual_service=""
    
    # Get database name (or use pre-filled)
    if [[ -z "${manual_db_name}" ]]; then
        while [[ -z "${manual_db_name}" ]]; do
            read -p "Enter Database Name: " manual_db_name
            manual_db_name=$(echo "${manual_db_name}" | xargs)
        done
    else
        echo "Database Name: ${manual_db_name} (from selection)"
    fi
    
    # Get SCAN host
    while [[ -z "${manual_scan}" ]]; do
        read -p "Enter SCAN Hostname/IP: " manual_scan
        manual_scan=$(echo "${manual_scan}" | xargs)
    done
    
    # Get service name
    while [[ -z "${manual_service}" ]]; do
        read -p "Enter Service Name: " manual_service
        manual_service=$(echo "${manual_service}" | xargs)
    done
    
    echo ""
    echo "You entered:"
    echo "  Database Name  : ${manual_db_name}"
    echo "  SCAN Host      : ${manual_scan}"
    echo "  Service Name   : ${manual_service}"
    echo ""
    read -p "Is this correct? (y/n): " confirm
    
    if [[ "${confirm}" =~ ^[Yy]$ ]]; then
        echo "${manual_db_name}|${manual_scan}|${manual_service}"
        return 0
    else
        echo "Manual input cancelled"
        return 1
    fi
}

################################################################################
# Function: select_database
# Description: Enhanced database selection with manual input option
# Returns: DB_NAME|SCAN_HOST|SERVICE_NAME or "ALL"
################################################################################
select_database() {
    echo "[DEBUG SELECT 1] Entered select_database function"
    
    local prompt_message="${1:-Select database}"
    
    echo "[DEBUG SELECT 2] Prompt message: ${prompt_message}"
    echo "[DEBUG SELECT 3] DATABASE_LIST_FILE: ${DATABASE_LIST_FILE}"
    
    echo ""
    echo "================================================================"
    echo " ${prompt_message}"
    echo "================================================================"
    
    echo "[DEBUG SELECT 4] About to start reading database file"
    
    # Load database list
    local -a databases=()
    local -a db_details=()
    local counter=1
    
    echo "[DEBUG] Starting database list display..."
    
    while IFS='|' read -r db_name scan_host service_name || [[ -n "$db_name" ]]; do
        # Skip comments and empty lines
        [[ "$db_name" =~ ^#.*$ ]] && continue
        [[ -z "$db_name" ]] && continue
        
        db_name=$(echo "$db_name" | xargs)
        scan_host=$(echo "$scan_host" | xargs)
        service_name=$(echo "$service_name" | xargs)
        
        databases+=("${db_name}")
        db_details+=("${db_name}|${scan_host}|${service_name}")
        printf "  %2d) %-20s (%s / %s)\n" "${counter}" "${db_name}" "${scan_host}" "${service_name}"
        ((counter++))
    done < "${DATABASE_LIST_FILE}"
    
    echo "[DEBUG] Completed database list. Found ${#databases[@]} databases."
    
    printf "  %2d) %-20s\n" "0" "ALL DATABASES"
    printf "  %2d) %-20s\n" "99" "MANUAL INPUT"
    echo ""
    
    while true; do
        read -p "Enter your choice (0-$((${#databases[@]})) or 99): " choice
        
        if [[ "${choice}" == "0" ]]; then
            SELECTED_DATABASE="ALL"
            return 0
        elif [[ "${choice}" == "99" ]]; then
            # Manual input
            echo ""
            echo "----------------------------------------------------------------"
            echo " Manual Database Input"
            echo "----------------------------------------------------------------"
            
            local manual_db_name=""
            local manual_scan=""
            local manual_service=""
            
            while [[ -z "${manual_db_name}" ]]; do
                read -p "Enter Database Name: " manual_db_name
                manual_db_name=$(echo "${manual_db_name}" | xargs)
            done
            
            while [[ -z "${manual_scan}" ]]; do
                read -p "Enter SCAN Hostname/IP: " manual_scan
                manual_scan=$(echo "${manual_scan}" | xargs)
            done
            
            while [[ -z "${manual_service}" ]]; do
                read -p "Enter Service Name: " manual_service
                manual_service=$(echo "${manual_service}" | xargs)
            done
            
            echo ""
            echo "You entered:"
            echo "  Database Name  : ${manual_db_name}"
            echo "  SCAN Host      : ${manual_scan}"
            echo "  Service Name   : ${manual_service}"
            echo ""
            read -p "Is this correct? (y/n): " confirm
            
            if [[ "${confirm}" =~ ^[Yy]$ ]]; then
                SELECTED_DATABASE="${manual_db_name}|${manual_scan}|${manual_service}"
                return 0
            else
                echo "Cancelled. Please select again."
                echo ""
                # Re-display menu
                echo "================================================================"
                echo " ${prompt_message}"
                echo "================================================================"
                counter=1
                for i in "${!databases[@]}"; do
                    IFS='|' read -r db_name scan_host service_name <<< "${db_details[$i]}"
                    printf "  %2d) %-20s (%s / %s)\n" "$((i+1))" "${db_name}" "${scan_host}" "${service_name}"
                done
                printf "  %2d) %-20s\n" "0" "ALL DATABASES"
                printf "  %2d) %-20s\n" "99" "MANUAL INPUT"
                echo ""
                continue
            fi
            
        elif [[ "${choice}" =~ ^[0-9]+$ ]] && [ "${choice}" -ge 1 ] && [ "${choice}" -le "${#databases[@]}" ]; then
            SELECTED_DATABASE="${db_details[$((choice-1))]}"
            return 0
        else
            echo "Invalid choice. Please try again."
        fi
    done
}

################################################################################
# Function: display_database_info
# Description: Displays selected database information
# Parameters: $1 - DB_NAME|SCAN_HOST|SERVICE_NAME or "ALL"
################################################################################
display_database_info() {
    local db_info=$1
    
    if [[ "${db_info}" == "ALL" ]]; then
        echo ""
        echo "================================================================"
        echo " Selected: ALL DATABASES"
        echo "================================================================"
        echo ""
        return
    fi
    
    IFS='|' read -r db_name scan_host service_name <<< "${db_info}"
    
    echo ""
    echo "================================================================"
    echo " Selected Database Information"
    echo "================================================================"
    echo "  Database Name  : ${db_name}"
    echo "  SCAN Host      : ${scan_host}"
    echo "  Service Name   : ${service_name}"
    echo "================================================================"
    echo ""
}

################################################################################
# Function: test_and_confirm_database_connection
# Description: Tests database connection and asks user to continue or abort
# Parameters: $1 - Database name
#            $2 - SCAN host
#            $3 - Service name
# Returns: 0 if user wants to continue, 1 if user wants to abort
################################################################################
test_and_confirm_database_connection() {
    local db_name=$1
    local scan_host=$2
    local service_name=$3
    
    echo ""
    echo "================================================================"
    echo " Testing Database Connection"
    echo "================================================================"
    echo "  Database: ${db_name}"
    echo "  SCAN Host: ${scan_host}"
    echo "  Service: ${service_name}"
    echo ""
    
    log_message "INFO" "Testing connection to ${db_name} (${scan_host}/${service_name})"
    
    if test_db_connection "${scan_host}" "${service_name}"; then
        echo "[OK] Connection successful!"
        log_message "INFO" "Connection test passed for ${db_name}"
        return 0
    else
        echo ""
        echo "+==============================================================+"
        echo "|  [!] CONNECTION FAILED                                       |"
        echo "+==============================================================+"
        echo ""
        echo "Cannot connect to database: ${db_name}"
        echo "  SCAN Host: ${scan_host}"
        echo "  Service: ${service_name}"
        echo ""
        log_message "ERROR" "Connection test failed for ${db_name}"
        
        echo "Possible causes:"
        echo "  * Database is down"
        echo "  * SCAN host unreachable"
        echo "  * Service name incorrect"
        echo "  * Network connectivity issues"
        echo "  * TNS listener not running"
        echo "  * Incorrect credentials"
        echo ""
        
        read -p "Do you want to continue anyway? (y/n): " continue_choice
        
        if [[ "${continue_choice}" =~ ^[Yy]$ ]]; then
            log_message "WARN" "User chose to continue despite connection failure"
            return 0
        else
            log_message "INFO" "Operation aborted due to connection failure"
            return 1
        fi
    fi
}

################################################################################
# Function: parse_database_selection
# Description: Parses database selection and returns individual components
# Parameters: $1 - Database selection (DB_NAME|SCAN|SERVICE or just DB_NAME)
# Returns: Sets global variables DB_NAME, SCAN_HOST, SERVICE_NAME
################################################################################
parse_database_selection() {
    local selection=$1
    
    if [[ "${selection}" == *"|"* ]]; then
        # Already in full format
        IFS='|' read -r DB_NAME SCAN_HOST SERVICE_NAME <<< "${selection}"
    else
        # Just database name, look it up
        while IFS='|' read -r db_name scan_host service_name || [[ -n "$db_name" ]]; do
            [[ "$db_name" =~ ^#.*$ ]] && continue
            [[ -z "$db_name" ]] && continue
            
            db_name=$(echo "$db_name" | xargs)
            
            if [[ "${db_name}" == "${selection}" ]]; then
                DB_NAME="${db_name}"
                SCAN_HOST=$(echo "$scan_host" | xargs)
                SERVICE_NAME=$(echo "$service_name" | xargs)
                return 0
            fi
        done < "${DATABASE_LIST_FILE}"
        
        # Not found in list
        log_message "ERROR" "Database ${selection} not found in configuration"
        return 1
    fi
    
    return 0
}

################################################################################
# Function: database_health_check_menu
# Description: Handles database health check menu
################################################################################
database_health_check_menu() {
    echo "[DEBUG 1] Entering database_health_check_menu function"
    
    display_banner
    
    echo "[DEBUG 2] After display_banner, before menu header"
    
    echo "+==============================================================+"
    echo "|              DATABASE HEALTH CHECK                           |"
    echo "+==============================================================+"
    
    echo "[DEBUG 3] About to call select_database"
    
    # Call select_database which sets SELECTED_DATABASE global variable
    select_database "Select database for health check"
    local selected_db="${SELECTED_DATABASE}"
    
    echo "[DEBUG 4] Returned from select_database: ${selected_db}"
    
    # Display selected database info
    display_database_info "${selected_db}"
    
    # Validate prerequisites
    if ! validate_prerequisites; then
        log_message "ERROR" "Prerequisites validation failed"
        read -p "Press Enter to continue..."
        return 1
    fi
    
    # Handle database selection format
    if [[ "${selected_db}" == "ALL" ]]; then
        # Load all databases
        local db_configs=$(load_database_list "ALL")
        
        if [[ -z "${db_configs}" ]]; then
            echo ""
            echo "[!] ERROR: No databases found in configuration file"
            echo ""
            echo "Would you like to enter database details manually? (y/n)"
            read -p "Choice: " manual_choice
            
            if [[ "${manual_choice}" =~ ^[Yy]$ ]]; then
                # Prompt for manual input
                local manual_db=$(prompt_manual_database_input)
                if [[ -n "${manual_db}" ]]; then
                    db_configs="${manual_db}"
                else
                    log_message "ERROR" "Manual input cancelled"
                    read -p "Press Enter to continue..."
                    return 1
                fi
            else
                log_message "ERROR" "No databases configured"
                read -p "Press Enter to continue..."
                return 1
            fi
        fi
        
    elif [[ "${selected_db}" == *"|"* ]]; then
        # Already in full format (manual input or new selection)
        local db_configs="${selected_db}"
        
    else
        # Just database name, look it up
        local db_configs=$(load_database_list "${selected_db}")
        
        if [[ -z "${db_configs}" ]]; then
            echo ""
            echo "[!] ERROR: Database '${selected_db}' not found in configuration file"
            echo ""
            echo "Would you like to enter database details manually? (y/n)"
            read -p "Choice: " manual_choice
            
            if [[ "${manual_choice}" =~ ^[Yy]$ ]]; then
                # Prompt for manual input with pre-filled database name
                local manual_db=$(prompt_manual_database_input "${selected_db}")
                if [[ -n "${manual_db}" ]]; then
                    db_configs="${manual_db}"
                else
                    log_message "ERROR" "Manual input cancelled"
                    read -p "Press Enter to continue..."
                    return 1
                fi
            else
                log_message "ERROR" "Database not found and manual input declined"
                read -p "Press Enter to continue..."
                return 1
            fi
        else
            # Database found in configuration - show details and ask for confirmation
            IFS='|' read -r found_db found_scan found_service <<< "${db_configs}"
            echo ""
            echo "================================================================"
            echo " Database Found in Configuration"
            echo "================================================================"
            echo "  Database Name  : ${found_db}"
            echo "  SCAN Host      : ${found_scan}"
            echo "  Service Name   : ${found_service}"
            echo "================================================================"
            echo ""
            read -p "Is this correct? Continue with this database? (y/n): " confirm_choice
            
            if [[ ! "${confirm_choice}" =~ ^[Yy]$ ]]; then
                echo ""
                echo "Would you like to enter different database details manually? (y/n)"
                read -p "Choice: " manual_choice
                
                if [[ "${manual_choice}" =~ ^[Yy]$ ]]; then
                    local manual_db=$(prompt_manual_database_input "${selected_db}")
                    if [[ -n "${manual_db}" ]]; then
                        db_configs="${manual_db}"
                    else
                        log_message "ERROR" "Manual input cancelled"
                        read -p "Press Enter to continue..."
                        return 1
                    fi
                else
                    log_message "INFO" "Operation cancelled by user"
                    read -p "Press Enter to continue..."
                    return 1
                fi
            fi
        fi
    fi
    
    # Final validation
    if [[ -z "${db_configs}" ]]; then
        log_message "ERROR" "No database configuration available"
        read -p "Press Enter to continue..."
        return 1
    fi
    
    # Process each database
    while IFS= read -r db_config; do
        IFS='|' read -r db_name scan_host service_name <<< "${db_config}"
        
        echo ""
        log_message "INFO" "Processing database: ${db_name}"
        echo "-------------------------------------------------------------"
        
        # Test database connection before proceeding
        if ! test_and_confirm_database_connection "${db_name}" "${scan_host}" "${service_name}"; then
            echo ""
            echo "[!] Skipping ${db_name} due to connection failure"
            log_message "WARN" "Skipped ${db_name} - connection test failed and user aborted"
            echo "-------------------------------------------------------------"
            continue
        fi
        
        echo ""
        # Generate health check report
        if generate_database_health_report "${db_name}" "${scan_host}" "${service_name}"; then
            log_message "INFO" "Health check completed successfully for ${db_name}"
        else
            log_message "ERROR" "Health check failed for ${db_name}"
        fi
        
        echo "-------------------------------------------------------------"
        
    done <<< "${db_configs}"
    
    echo ""
    log_message "INFO" "Database health check process completed"
    echo ""
    read -p "Press Enter to continue..."
}

################################################################################
# Function: dataguard_health_check_menu
# Description: Handles Data Guard health check menu
################################################################################
dataguard_health_check_menu() {
    display_banner
    echo "+==============================================================+"
    echo "|            DATA GUARD HEALTH CHECK                           |"
    echo "+==============================================================+"
    
    select_database "Select database for Data Guard health check"
    local selected_db="${SELECTED_DATABASE}"
    
    # Display selected database info
    display_database_info "${selected_db}"
    
    # Validate prerequisites
    if ! validate_prerequisites; then
        log_message "ERROR" "Prerequisites validation failed"
        read -p "Press Enter to continue..."
        return 1
    fi
    
    # Handle database selection format
    if [[ "${selected_db}" == "ALL" ]]; then
        local db_configs=$(load_database_list "ALL")
        
        if [[ -z "${db_configs}" ]]; then
            echo ""
            echo "[!] ERROR: No databases found in configuration file"
            echo ""
            echo "Would you like to enter database details manually? (y/n)"
            read -p "Choice: " manual_choice
            
            if [[ "${manual_choice}" =~ ^[Yy]$ ]]; then
                local manual_db=$(prompt_manual_database_input)
                if [[ -n "${manual_db}" ]]; then
                    db_configs="${manual_db}"
                else
                    log_message "ERROR" "Manual input cancelled"
                    read -p "Press Enter to continue..."
                    return 1
                fi
            else
                log_message "ERROR" "No databases configured"
                read -p "Press Enter to continue..."
                return 1
            fi
        fi
        
    elif [[ "${selected_db}" == *"|"* ]]; then
        local db_configs="${selected_db}"
        
    else
        local db_configs=$(load_database_list "${selected_db}")
        
        if [[ -z "${db_configs}" ]]; then
            echo ""
            echo "[!] ERROR: Database '${selected_db}' not found in configuration file"
            echo ""
            echo "Would you like to enter database details manually? (y/n)"
            read -p "Choice: " manual_choice
            
            if [[ "${manual_choice}" =~ ^[Yy]$ ]]; then
                local manual_db=$(prompt_manual_database_input "${selected_db}")
                if [[ -n "${manual_db}" ]]; then
                    db_configs="${manual_db}"
                else
                    log_message "ERROR" "Manual input cancelled"
                    read -p "Press Enter to continue..."
                    return 1
                fi
            else
                log_message "ERROR" "Database not found and manual input declined"
                read -p "Press Enter to continue..."
                return 1
            fi
        else
            # Database found - show details and ask for confirmation
            IFS='|' read -r found_db found_scan found_service <<< "${db_configs}"
            echo ""
            echo "================================================================"
            echo " Database Found in Configuration"
            echo "================================================================"
            echo "  Database Name  : ${found_db}"
            echo "  SCAN Host      : ${found_scan}"
            echo "  Service Name   : ${found_service}"
            echo "================================================================"
            echo ""
            read -p "Is this correct? Continue with this database? (y/n): " confirm_choice
            
            if [[ ! "${confirm_choice}" =~ ^[Yy]$ ]]; then
                echo ""
                echo "Would you like to enter different database details manually? (y/n)"
                read -p "Choice: " manual_choice
                
                if [[ "${manual_choice}" =~ ^[Yy]$ ]]; then
                    local manual_db=$(prompt_manual_database_input "${selected_db}")
                    if [[ -n "${manual_db}" ]]; then
                        db_configs="${manual_db}"
                    else
                        log_message "ERROR" "Manual input cancelled"
                        read -p "Press Enter to continue..."
                        return 1
                    fi
                else
                    log_message "INFO" "Operation cancelled by user"
                    read -p "Press Enter to continue..."
                    return 1
                fi
            fi
        fi
    fi
    
    if [[ -z "${db_configs}" ]]; then
        log_message "ERROR" "No database configuration available"
        read -p "Press Enter to continue..."
        return 1
    fi
    
    # For Data Guard health check, we only need ONE database to start with
    # The DG health report will automatically discover all members
    # Extract just the first database if multiple were selected
    local first_db=$(echo "${db_configs}" | head -1)
    IFS='|' read -r db_name scan_host service_name <<< "${first_db}"
    
    echo ""
    log_message "INFO" "Starting Data Guard health check from database: ${db_name}"
    echo "-------------------------------------------------------------"
    echo "Note: Data Guard configuration will be auto-discovered"
    echo "      All primary and standby databases will be checked"
    echo "-------------------------------------------------------------"
    echo ""
    
    # Test database connection before proceeding
    if ! test_and_confirm_database_connection "${db_name}" "${scan_host}" "${service_name}"; then
        echo ""
        echo "[!] Cannot proceed - connection to ${db_name} failed"
        log_message "ERROR" "Data Guard health check aborted - cannot connect to ${db_name}"
        read -p "Press Enter to continue..."
        return 1
    fi
    
    echo ""
    # Generate Data Guard health check report
    # This will automatically discover and check ALL DG members
    if generate_dg_health_report "${db_name}"; then
        log_message "INFO" "Data Guard health check completed successfully"
    else
        log_message "ERROR" "Data Guard health check failed"
    fi
    
    echo ""
    log_message "INFO" "Data Guard health check process completed"
    echo ""
    read -p "Press Enter to continue..."
}

################################################################################
# Function: dataguard_switchover_menu
# Description: Handles Data Guard switchover menu
################################################################################
dataguard_switchover_menu() {
    display_banner
    echo "+==============================================================+"
    echo "|            DATA GUARD SWITCHOVER                             |"
    echo "+==============================================================+"
    
    select_database "Select database for switchover"
    local selected_db="${SELECTED_DATABASE}"
    
    if [[ "${selected_db}" == "ALL" ]]; then
        echo ""
        log_message "ERROR" "Switchover cannot be performed on ALL databases"
        echo "Please select a specific database."
        read -p "Press Enter to continue..."
        return 1
    fi
    
    # Display selected database info
    display_database_info "${selected_db}"
    
    # Validate prerequisites
    if ! validate_prerequisites; then
        log_message "ERROR" "Prerequisites validation failed"
        read -p "Press Enter to continue..."
        return 1
    fi
    
    # Parse database selection if needed
    if [[ "${selected_db}" == *"|"* ]]; then
        IFS='|' read -r db_name scan_host service_name <<< "${selected_db}"
    else
        # Try to look up in database_list.txt
        local db_configs=$(load_database_list "${selected_db}")
        
        if [[ -z "${db_configs}" ]]; then
            echo ""
            echo "[!] ERROR: Database '${selected_db}' not found in configuration file"
            echo ""
            echo "Would you like to enter database details manually? (y/n)"
            read -p "Choice: " manual_choice
            
            if [[ "${manual_choice}" =~ ^[Yy]$ ]]; then
                local manual_db=$(prompt_manual_database_input "${selected_db}")
                if [[ -n "${manual_db}" ]]; then
                    IFS='|' read -r db_name scan_host service_name <<< "${manual_db}"
                else
                    log_message "ERROR" "Manual input cancelled"
                    read -p "Press Enter to continue..."
                    return 1
                fi
            else
                log_message "ERROR" "Database not found and manual input declined"
                read -p "Press Enter to continue..."
                return 1
            fi
        else
            # Database found - show details and ask for confirmation
            IFS='|' read -r found_db found_scan found_service <<< "${db_configs}"
            echo ""
            echo "================================================================"
            echo " Database Found in Configuration"
            echo "================================================================"
            echo "  Database Name  : ${found_db}"
            echo "  SCAN Host      : ${found_scan}"
            echo "  Service Name   : ${found_service}"
            echo "================================================================"
            echo ""
            read -p "Is this correct? Continue with this database? (y/n): " confirm_choice
            
            if [[ ! "${confirm_choice}" =~ ^[Yy]$ ]]; then
                echo ""
                echo "Would you like to enter different database details manually? (y/n)"
                read -p "Choice: " manual_choice
                
                if [[ "${manual_choice}" =~ ^[Yy]$ ]]; then
                    local manual_db=$(prompt_manual_database_input "${selected_db}")
                    if [[ -n "${manual_db}" ]]; then
                        IFS='|' read -r db_name scan_host service_name <<< "${manual_db}"
                    else
                        log_message "ERROR" "Manual input cancelled"
                        read -p "Press Enter to continue..."
                        return 1
                    fi
                else
                    log_message "INFO" "Operation cancelled by user"
                    read -p "Press Enter to continue..."
                    return 1
                fi
            else
                IFS='|' read -r db_name scan_host service_name <<< "${db_configs}"
            fi
        fi
    fi
    
    # Get Data Guard configuration using DGMGRL
    log_message "INFO" "Getting Data Guard configuration..."
    
    if ! get_dg_broker_configuration "${db_name}"; then
        log_message "ERROR" "Failed to get Data Guard configuration for ${db_name}"
        echo ""
        echo "[!] Error: Cannot connect to Data Guard Broker"
        echo "    Make sure Data Guard Broker is configured and running."
        read -p "Press Enter to continue..."
        return 1
    fi
    
    # Identify primary database using DGMGRL
    log_message "INFO" "Identifying primary database..."
    
    if ! get_primary_database_dgmgrl; then
        log_message "ERROR" "Cannot identify primary database"
        echo ""
        echo "[!] Error: Cannot identify primary database in Data Guard configuration"
        read -p "Press Enter to continue..."
        return 1
    fi
    
    echo ""
    echo "Primary Database: ${PRIMARY_DB_UNIQUE_NAME}"
    echo ""
    
    # Get all standby databases using DGMGRL
    log_message "INFO" "Getting standby databases..."
    
    if ! get_all_standby_databases_dgmgrl; then
        log_message "ERROR" "Cannot get standby databases"
        echo ""
        echo "[!] Error: No standby databases found"
        read -p "Press Enter to continue..."
        return 1
    fi
    
    echo "Standby Databases:"
    for standby_db in "${STANDBY_DBS_ARRAY[@]}"; do
        echo "  - ${standby_db}"
    done
    echo ""
    
    # Get target database for switchover
    read -p "Enter target database name for switchover: " target_db
    
    if [[ -z "${target_db}" ]]; then
        log_message "ERROR" "Target database name cannot be empty"
        read -p "Press Enter to continue..."
        return 1
    fi
    
    # Debug: Show what's in the array
    log_message "INFO" "Validating target '${target_db}' against ${#STANDBY_DBS_ARRAY[@]} standby databases"
    echo ""
    echo "DEBUG: Available standbys in array:"
    for idx in "${!STANDBY_DBS_ARRAY[@]}"; do
        echo "  [$idx] = '${STANDBY_DBS_ARRAY[$idx]}'"
    done
    echo ""
    
    # Validate target is in the standby list
    local target_valid=0
    for standby_db in "${STANDBY_DBS_ARRAY[@]}"; do
        log_message "INFO" "Comparing '${standby_db}' with '${target_db}'"
        if [[ "${standby_db}" == "${target_db}" ]]; then
            target_valid=1
            log_message "INFO" "Match found!"
            break
        fi
    done
    
    if [[ ${target_valid} -eq 0 ]]; then
        log_message "ERROR" "Target database '${target_db}' is not a valid standby database"
        echo ""
        echo "[!] Error: '${target_db}' is not in the standby database list"
        echo "Available standbys:"
        for standby_db in "${STANDBY_DBS_ARRAY[@]}"; do
            echo "  - ${standby_db}"
        done
        read -p "Press Enter to continue..."
        return 1
    fi
    
    # Confirmation
    echo ""
    echo "+==============================================================+"
    echo "|                    SWITCHOVER CONFIRMATION                   |"
    echo "+==============================================================+"
    echo "|                                                              |"
    echo "|  WARNING: This operation will switch the database roles      |"
    echo "|                                                              |"
    echo "|  Current Primary: ${PRIMARY_DB_UNIQUE_NAME}"
    echo "|  Target Database: ${target_db}"
    echo "|                                                              |"
    echo "|  This operation may cause brief service interruption.        |"
    echo "|                                                              |"
    echo "+==============================================================+"
    echo ""
    
    read -p "Are you sure you want to proceed? (yes/no): " confirmation
    
    if [[ "${confirmation}" != "yes" ]]; then
        log_message "INFO" "Switchover cancelled by user"
        read -p "Press Enter to continue..."
        return 0
    fi
    
    # Additional confirmation
    read -p "Type '${target_db}' to confirm: " confirm_target
    
    if [[ "${confirm_target}" != "${target_db}" ]]; then
        log_message "ERROR" "Confirmation failed - target database name mismatch"
        read -p "Press Enter to continue..."
        return 1
    fi
    
    echo ""
    echo "================================================================"
    echo " Starting Data Guard Switchover Process"
    echo "================================================================"
    echo ""
    
    # Execute switchover with validation
    if execute_switchover_with_validation "${selected_db}" "${target_db}"; then
        echo ""
        echo "+==============================================================+"
        echo "|          SWITCHOVER COMPLETED SUCCESSFULLY                   |"
        echo "+==============================================================+"
        log_message "INFO" "Switchover completed successfully"
    else
        echo ""
        echo "+==============================================================+"
        echo "|              SWITCHOVER FAILED                               |"
        echo "+==============================================================+"
        log_message "ERROR" "Switchover failed"
    fi
    
    echo ""
    read -p "Press Enter to continue..."
}

################################################################################
# Function: restore_point_menu
# Description: Handles restore point management menu
################################################################################
restore_point_menu() {
    display_banner
    echo "+==============================================================+"
    echo "|            RESTORE POINT MANAGEMENT                          |"
    echo "+==============================================================+"
    
    select_database "Select database for restore point operations"
    local selected_db="${SELECTED_DATABASE}"
    
    if [[ "${selected_db}" == "ALL" ]]; then
        echo ""
        log_message "ERROR" "Restore point operations must be performed on a specific database"
        echo "Please select a specific database."
        read -p "Press Enter to continue..."
        return 1
    fi
    
    # Display selected database info
    display_database_info "${selected_db}"
    
    # Validate prerequisites
    if ! validate_prerequisites; then
        log_message "ERROR" "Prerequisites validation failed"
        read -p "Press Enter to continue..."
        return 1
    fi
    
    # Parse database selection
    if [[ "${selected_db}" == *"|"* ]]; then
        # Already in full format
        IFS='|' read -r db_name scan_host service_name <<< "${selected_db}"
    else
        # Load from configuration
        local db_configs=$(load_database_list "${selected_db}")
        
        if [[ -z "${db_configs}" ]]; then
            echo ""
            echo "[!] ERROR: Database '${selected_db}' not found in configuration file"
            echo ""
            echo "Would you like to enter database details manually? (y/n)"
            read -p "Choice: " manual_choice
            
            if [[ "${manual_choice}" =~ ^[Yy]$ ]]; then
                local manual_db=$(prompt_manual_database_input "${selected_db}")
                if [[ -n "${manual_db}" ]]; then
                    IFS='|' read -r db_name scan_host service_name <<< "${manual_db}"
                else
                    log_message "ERROR" "Manual input cancelled"
                    read -p "Press Enter to continue..."
                    return 1
                fi
            else
                log_message "ERROR" "Database not found and manual input declined"
                read -p "Press Enter to continue..."
                return 1
            fi
        else
            # Database found - show details and ask for confirmation
            IFS='|' read -r found_db found_scan found_service <<< "${db_configs}"
            echo ""
            echo "================================================================"
            echo " Database Found in Configuration"
            echo "================================================================"
            echo "  Database Name  : ${found_db}"
            echo "  SCAN Host      : ${found_scan}"
            echo "  Service Name   : ${found_service}"
            echo "================================================================"
            echo ""
            read -p "Is this correct? Continue with this database? (y/n): " confirm_choice
            
            if [[ ! "${confirm_choice}" =~ ^[Yy]$ ]]; then
                echo ""
                echo "Would you like to enter different database details manually? (y/n)"
                read -p "Choice: " manual_choice
                
                if [[ "${manual_choice}" =~ ^[Yy]$ ]]; then
                    local manual_db=$(prompt_manual_database_input "${selected_db}")
                    if [[ -n "${manual_db}" ]]; then
                        IFS='|' read -r db_name scan_host service_name <<< "${manual_db}"
                    else
                        log_message "ERROR" "Manual input cancelled"
                        read -p "Press Enter to continue..."
                        return 1
                    fi
                else
                    log_message "INFO" "Operation cancelled by user"
                    read -p "Press Enter to continue..."
                    return 1
                fi
            else
                IFS='|' read -r db_name scan_host service_name <<< "${db_configs}"
            fi
        fi
    fi
    
    # Test connection
    if ! test_db_connection "${scan_host}" "${service_name}"; then
        log_message "ERROR" "Cannot connect to database ${db_name}"
        read -p "Press Enter to continue..."
        return 1
    fi
    
    # Validate restore point prerequisites
    validate_restore_point_prerequisites "${scan_host}" "${service_name}"
    
    # Display submenu
    while true; do
        echo ""
        echo "+==============================================================+"
        echo "|           RESTORE POINT OPERATIONS - ${db_name}"
        echo "+==============================================================+"
        echo "|  1) List All Restore Points                                  |"
        echo "|  2) Create Restore Point                                     |"
        echo "|  3) Drop Restore Point                                       |"
        echo "|  4) Drop All Restore Points                                  |"
        echo "|  5) Generate Restore Point Report                            |"
        echo "|  0) Return to Main Menu                                      |"
        echo "+==============================================================+"
        echo ""
        
        read -p "Enter your choice: " rp_choice
        
        case ${rp_choice} in
            1)
                # List all restore points
                echo ""
                echo "================================================================"
                echo " Current Restore Points"
                echo "================================================================"
                echo ""
                
                local rp_count=$(get_restore_point_count "${scan_host}" "${service_name}")
                
                if [[ ${rp_count} -eq 0 ]]; then
                    log_message "INFO" "No restore points found"
                else
                    log_message "INFO" "Found ${rp_count} restore point(s)"
                    echo ""
                    
                    # Display restore points
                    ${ORACLE_HOME}/bin/sqlplus -S /nolog << EOF
connect ${SYS_USER}/${SYS_PASSWORD}@${scan_host}/${service_name} ${SYS_CONNECT_MODE}
set linesize 200 pagesize 1000
column name format a30
column creation_time format a20
column guarantee_flashback_database format a10 heading "GUARANTEE"
column size_mb format 999,999.99
column preserved format a10

SELECT 
    name,
    scn,
    to_char(time, 'YYYY-MM-DD HH24:MI:SS') as "CREATION_TIME",
    guarantee_flashback_database,
    storage_size/1024/1024 as "SIZE_MB",
    preserved
FROM v\$restore_point
ORDER BY time DESC;
exit;
EOF
                fi
                
                echo ""
                read -p "Press Enter to continue..."
                ;;
                
            2)
                # Create restore point
                echo ""
                echo "================================================================"
                echo " Create Restore Point"
                echo "================================================================"
                echo ""
                
                read -p "Enter restore point name: " rp_name
                
                if [[ -z "${rp_name}" ]]; then
                    log_message "ERROR" "Restore point name cannot be empty"
                    read -p "Press Enter to continue..."
                    continue
                fi
                
                echo ""
                read -p "Guarantee flashback database? (yes/no) [no]: " guarantee
                guarantee=${guarantee:-no}
                
                if [[ "${guarantee}" == "yes" ]] || [[ "${guarantee}" == "YES" ]]; then
                    guarantee="YES"
                    echo ""
                    echo "[!]️  WARNING: Guaranteed restore points require Fast Recovery Area"
                    echo "   and prevent flashback logs from being aged out automatically."
                    echo ""
                    read -p "Continue with guaranteed restore point? (yes/no): " confirm_guarantee
                    
                    if [[ "${confirm_guarantee}" != "yes" ]]; then
                        log_message "INFO" "Restore point creation cancelled"
                        read -p "Press Enter to continue..."
                        continue
                    fi
                else
                    guarantee="NO"
                fi
                
                echo ""
                log_message "INFO" "Creating restore point: ${rp_name}"
                
                if create_restore_point "${scan_host}" "${service_name}" "${rp_name}" "${guarantee}"; then
                    echo ""
                    echo "+==============================================================+"
                    echo "|         RESTORE POINT CREATED SUCCESSFULLY                   |"
                    echo "+==============================================================+"
                    log_message "INFO" "Restore point '${rp_name}' created successfully"
                    
                    # Display details
                    echo ""
                    ${ORACLE_HOME}/bin/sqlplus -S /nolog << EOF
connect ${SYS_USER}/${SYS_PASSWORD}@${scan_host}/${service_name} ${SYS_CONNECT_MODE}
set linesize 200 pagesize 1000
column name format a30
column creation_time format a20

SELECT 
    name,
    scn,
    to_char(time, 'YYYY-MM-DD HH24:MI:SS') as "CREATION_TIME",
    guarantee_flashback_database,
    storage_size/1024/1024 as "SIZE_MB"
FROM v\$restore_point
WHERE upper(name) = upper('${rp_name}');
exit;
EOF
                else
                    echo ""
                    echo "+==============================================================+"
                    echo "|           RESTORE POINT CREATION FAILED                      |"
                    echo "+==============================================================+"
                    log_message "ERROR" "Failed to create restore point '${rp_name}'"
                fi
                
                echo ""
                read -p "Press Enter to continue..."
                ;;
                
            3)
                # Drop restore point
                echo ""
                echo "================================================================"
                echo " Drop Restore Point"
                echo "================================================================"
                echo ""
                
                # List current restore points
                local rp_count=$(get_restore_point_count "${scan_host}" "${service_name}")
                
                if [[ ${rp_count} -eq 0 ]]; then
                    log_message "INFO" "No restore points available to drop"
                    read -p "Press Enter to continue..."
                    continue
                fi
                
                log_message "INFO" "Current restore points:"
                echo ""
                
                ${ORACLE_HOME}/bin/sqlplus -S /nolog << EOF
connect ${SYS_USER}/${SYS_PASSWORD}@${scan_host}/${service_name} ${SYS_CONNECT_MODE}
set linesize 200 pagesize 1000
column name format a30
column creation_time format a20

SELECT 
    name,
    scn,
    to_char(time, 'YYYY-MM-DD HH24:MI:SS') as "CREATION_TIME",
    guarantee_flashback_database
FROM v\$restore_point
ORDER BY time DESC;
exit;
EOF
                
                echo ""
                read -p "Enter restore point name to drop: " rp_name
                
                if [[ -z "${rp_name}" ]]; then
                    log_message "ERROR" "Restore point name cannot be empty"
                    read -p "Press Enter to continue..."
                    continue
                fi
                
                echo ""
                read -p "Are you sure you want to drop restore point '${rp_name}'? (yes/no): " confirm
                
                if [[ "${confirm}" != "yes" ]]; then
                    log_message "INFO" "Drop operation cancelled"
                    read -p "Press Enter to continue..."
                    continue
                fi
                
                echo ""
                log_message "INFO" "Dropping restore point: ${rp_name}"
                
                if drop_restore_point "${scan_host}" "${service_name}" "${rp_name}"; then
                    echo ""
                    echo "+==============================================================+"
                    echo "|         RESTORE POINT DROPPED SUCCESSFULLY                   |"
                    echo "+==============================================================+"
                    log_message "INFO" "Restore point '${rp_name}' dropped successfully"
                else
                    echo ""
                    echo "+==============================================================+"
                    echo "|           RESTORE POINT DROP FAILED                          |"
                    echo "+==============================================================+"
                    log_message "ERROR" "Failed to drop restore point '${rp_name}'"
                fi
                
                echo ""
                read -p "Press Enter to continue..."
                ;;
                
            4)
                # Drop all restore points
                echo ""
                echo "================================================================"
                echo " Drop All Restore Points"
                echo "================================================================"
                echo ""
                
                local rp_count=$(get_restore_point_count "${scan_host}" "${service_name}")
                
                if [[ ${rp_count} -eq 0 ]]; then
                    log_message "INFO" "No restore points available to drop"
                    read -p "Press Enter to continue..."
                    continue
                fi
                
                log_message "INFO" "Found ${rp_count} restore point(s) to drop"
                echo ""
                
                # List all restore points
                ${ORACLE_HOME}/bin/sqlplus -S /nolog << EOF
connect ${SYS_USER}/${SYS_PASSWORD}@${scan_host}/${service_name} ${SYS_CONNECT_MODE}
set linesize 200 pagesize 1000
column name format a30
column creation_time format a20

SELECT 
    name,
    scn,
    to_char(time, 'YYYY-MM-DD HH24:MI:SS') as "CREATION_TIME",
    guarantee_flashback_database
FROM v\$restore_point
ORDER BY time DESC;
exit;
EOF
                
                echo ""
                echo "[!]️  WARNING: This will drop ALL restore points!"
                echo ""
                read -p "Are you sure you want to drop ALL ${rp_count} restore point(s)? (yes/no): " confirm
                
                if [[ "${confirm}" != "yes" ]]; then
                    log_message "INFO" "Drop all operation cancelled"
                    read -p "Press Enter to continue..."
                    continue
                fi
                
                # Additional confirmation
                read -p "Type 'DROP ALL' to confirm: " confirm_text
                
                if [[ "${confirm_text}" != "DROP ALL" ]]; then
                    log_message "ERROR" "Confirmation failed - operation cancelled"
                    read -p "Press Enter to continue..."
                    continue
                fi
                
                echo ""
                log_message "INFO" "Dropping all restore points..."
                
                if drop_all_restore_points "${scan_host}" "${service_name}"; then
                    echo ""
                    echo "+==============================================================+"
                    echo "|       ALL RESTORE POINTS DROPPED SUCCESSFULLY                |"
                    echo "+==============================================================+"
                    log_message "INFO" "All restore points dropped successfully"
                else
                    echo ""
                    echo "+==============================================================+"
                    echo "|         SOME RESTORE POINTS FAILED TO DROP                   |"
                    echo "+==============================================================+"
                    log_message "ERROR" "Failed to drop some restore points"
                fi
                
                echo ""
                read -p "Press Enter to continue..."
                ;;
                
            5)
                # Generate restore point report
                echo ""
                echo "================================================================"
                echo " Generate Restore Point Report"
                echo "================================================================"
                echo ""
                
                log_message "INFO" "Generating restore point report for ${db_name}"
                
                if generate_restore_point_report "${db_name}" "${scan_host}" "${service_name}"; then
                    echo ""
                    log_message "INFO" "Report generated successfully"
                else
                    echo ""
                    log_message "ERROR" "Failed to generate report"
                fi
                
                echo ""
                read -p "Press Enter to continue..."
                ;;
                
            0)
                return 0
                ;;
                
            *)
                echo ""
                echo "Invalid choice. Please try again."
                sleep 2
                ;;
        esac
    done
}

################################################################################
# Function: system_config_menu
# Description: Displays and allows editing of system configuration
################################################################################
system_config_menu() {
    display_banner
    echo "+==============================================================+"
    echo "|              SYSTEM CONFIGURATION                            |"
    echo "+==============================================================+"
    echo ""
    
    echo "Configuration File: ${CONFIG_FILE}"
    echo "Database List File: ${DATABASE_LIST_FILE}"
    echo ""
    echo "Current Configuration:"
    echo "-------------------------------------------------------------"
    echo "Log Directory:    ${LOG_BASE_DIR}"
    echo "Report Directory: ${REPORT_BASE_DIR}"
    echo "Email From:       ${EMAIL_FROM}"
    echo "Email Recipients: ${EMAIL_RECIPIENTS}"
    echo "SMTP Server:      ${SMTP_SERVER}"
    echo "Oracle Home:      ${ORACLE_HOME}"
    echo "-------------------------------------------------------------"
    echo ""
    
    echo "Options:"
    echo "  1) Edit configuration file"
    echo "  2) Edit database list"
    echo "  3) Test email configuration"
    echo "  4) View database list"
    echo "  0) Return to main menu"
    echo ""
    
    read -p "Enter your choice: " choice
    
    case ${choice} in
        1)
            ${EDITOR:-vi} "${CONFIG_FILE}"
            ;;
        2)
            ${EDITOR:-vi} "${DATABASE_LIST_FILE}"
            ;;
        3)
            echo "Testing email configuration..."
            echo "<h1>Test Email</h1><p>This is a test email from Oracle RAC Admin script.</p>" > /tmp/test_email.html
            send_email "Test Email" "/tmp/test_email.html"
            rm -f /tmp/test_email.html
            ;;
        4)
            echo ""
            echo "Database List (Format: DB_NAME|SCAN_HOST|SERVICE_NAME):"
            echo "-------------------------------------------------------------"
            cat "${DATABASE_LIST_FILE}" | grep -v "^#" | grep -v "^$"
            echo "-------------------------------------------------------------"
            ;;
        0)
            return
            ;;
        *)
            echo "Invalid choice"
            ;;
    esac
    
    echo ""
    read -p "Press Enter to continue..."
}

################################################################################
# Function: view_logs_menu
# Description: Displays recent log entries
################################################################################
view_logs_menu() {
    display_banner
    echo "+==============================================================+"
    echo "|                   VIEW LOGS                                  |"
    echo "+==============================================================+"
    echo ""
    
    local log_file="${LOG_BASE_DIR}/oracle_admin_$(date '+%Y%m%d').log"
    
    if [[ ! -f "${log_file}" ]]; then
        echo "No log file found for today: ${log_file}"
    else
        echo "Displaying last 50 lines of today's log:"
        echo "-------------------------------------------------------------"
        tail -50 "${log_file}"
        echo "-------------------------------------------------------------"
    fi
    
    echo ""
    read -p "Press Enter to continue..."
}

################################################################################
# Function: cleanup_menu
# Description: Cleanup old reports and logs
################################################################################
cleanup_menu() {
    display_banner
    echo "+==============================================================+"
    echo "|              CLEANUP OLD REPORTS                             |"
    echo "+==============================================================+"
    echo ""
    
    echo "Current Retention Settings:"
    echo "  Report Retention: ${REPORT_RETENTION_DAYS} days"
    echo "  Log Retention:    ${LOG_RETENTION_DAYS} days"
    echo ""
    
    read -p "Do you want to proceed with cleanup? (yes/no): " confirmation
    
    if [[ "${confirmation}" == "yes" ]]; then
        echo ""
        cleanup_old_files "${REPORT_BASE_DIR}" "${REPORT_RETENTION_DAYS}"
        cleanup_old_files "${LOG_BASE_DIR}" "${LOG_RETENTION_DAYS}"
        echo ""
        log_message "INFO" "Cleanup completed"
    else
        echo "Cleanup cancelled"
    fi
    
    echo ""
    read -p "Press Enter to continue..."
}

################################################################################
# Function: main
# Description: Main function - entry point
################################################################################
main() {
    # Check if running as oracle user (recommended)
    if [[ "${USER}" != "oracle" ]] && [[ "${USER}" != "root" ]]; then
        log_message "WARN" "Script is not running as oracle user. Some operations may fail."
    fi
    
    # Main loop
    while true; do
        display_banner
        display_main_menu
        
        read -p "Enter your choice: " choice
        
        case ${choice} in
            1)
                database_health_check_menu
                ;;
            2)
                dataguard_health_check_menu
                ;;
            3)
                dataguard_switchover_menu
                ;;
            4)
                restore_point_menu
                ;;
            5)
                system_config_menu
                ;;
            6)
                view_logs_menu
                ;;
            7)
                cleanup_menu
                ;;
            0)
                echo ""
                echo "Thank you for using Oracle RAC Database Administration System"
                echo "Exiting..."
                log_message "INFO" "Script terminated by user"
                exit 0
                ;;
            *)
                echo ""
                echo "Invalid choice. Please try again."
                sleep 2
                ;;
        esac
    done
}

################################################################################
# Script Execution
################################################################################

# Trap errors
trap 'log_message "ERROR" "Script terminated unexpectedly at line $LINENO"' ERR

# Start main function
main "$@"

################################################################################
# End of Script
################################################################################

# Quick Reference Guide
## Oracle RAC Administration Scripts v2.1

---

## 🚀 Quick Start

### 1. Deploy Scripts
```bash
# Run deployment script
./deploy.sh

# Or manually:
chmod +x *.sh
mkdir -p config logs reports backups
```

### 2. Configure Databases
```bash
# Edit database list
vi config/database_list.txt

# Format: DB_NAME|SCAN_HOST|SERVICE_NAME
PRODDB|prod-scan.company.com|PRODDB_SVC
TESTDB|test-scan.company.com|TESTDB_SVC
```

### 3. Run the System
```bash
./oracle_rac_admin.sh
```

---

## 📋 Menu Options Quick Reference

### Main Menu

| Option | Function | Description |
|--------|----------|-------------|
| 1 | Health Check | Run database health check, generate HTML report |
| 2 | DG Status | Show Data Guard configuration and status |
| 3 | DG Switchover | Perform role switchover with validation |
| 4 | Restore Points | Manage guaranteed restore points |
| 5 | View Databases | List all configured databases |
| 6 | Reload List | Reload database configuration |
| 7 | View Logs | Show recent log entries |
| 0 | Exit | Quit the system |

---

## 🔧 Common Tasks

### Check Database Health
```
1. Choose option 1 (Database Health Check)
2. Select database from list
3. Confirm operation
4. View HTML report in reports/ directory
```

### Perform Switchover
```
1. Choose option 3 (Data Guard Switchover)
2. Select CURRENT primary database
3. Select TARGET standby database
4. Review switchover plan
5. Type 'SWITCHOVER' to confirm
6. Monitor progress
```

### Create Restore Point
```
1. Choose option 4 (Restore Point Management)
2. Select database
3. Choose option 3 (Create Guaranteed Restore Point)
4. Enter restore point name
5. Confirm creation
```

---

## 📁 File Structure

```
oracle_rac_admin/
├── oracle_rac_admin.sh          # Main script
├── functions_common.sh           # Core functions
├── functions_db_health.sh        # Health checks
├── functions_dg_health.sh        # Data Guard status
├── functions_dg_switchover.sh    # Switchover operations
├── functions_restore_point.sh    # Restore point management
├── deploy.sh                     # Deployment script
├── UPDATE_SUMMARY.md             # Full documentation
├── QUICK_REFERENCE.md            # This file
├── config/
│   ├── database_list.txt         # Database configurations
│   └── script_config.conf        # System settings
├── logs/                         # Operation logs
├── reports/                      # HTML reports
└── backups/                      # Backup files
```

---

## 🔍 Troubleshooting

### Problem: No databases show in menu

**Quick Fix:**
```bash
# Check database list file
cat config/database_list.txt

# Ensure format is correct:
DB_NAME|SCAN_HOST|SERVICE_NAME

# No spaces around the | delimiter!
```

### Problem: Cannot connect to database

**Quick Fix:**
```bash
# Test connection manually
sqlplus sys/password@scan-host/service as sysdba

# Check listener
lsnrctl status

# Verify service
tnsping service_name
```

### Problem: Function not found

**Quick Fix:**
```bash
# Verify all files present
ls -l functions_*.sh

# Check syntax
bash -n oracle_rac_admin.sh

# Ensure executable
chmod +x *.sh
```

---

## 📝 Configuration File Examples

### database_list.txt
```
# Production
PRODDB|prod-scan.company.com|PRODDB_SVC
PRODSTBY|prodstby-scan.company.com|PRODSTBY_SVC

# Test
TESTDB|test-scan.company.com|TESTDB_SVC

# Dev
DEVDB|dev-scan.company.com|DEVDB_SVC
```

### script_config.conf
```bash
SYS_USER="sys"
SYS_PASSWORD="your_secure_password"

MAIL_ENABLED="YES"
MAIL_TO="dba@company.com"

ENABLE_AUDIT_LOG="YES"
LOG_RETENTION_DAYS=30
```

---

## 🎯 Key Functions

### Database Selection
- `select_database_from_menu()` - Interactive selection
- Returns database index
- Press 0 to cancel

### Connection Testing
- `test_db_connection(scan, service)` - Test connectivity
- Returns 0 on success, 1 on failure
- Logs all attempts

### Database Info
- `get_database_info_by_index(index)` - Get DB details
- Sets global variables:
  - `$SELECTED_DB_NAME`
  - `$SELECTED_DB_HOST`
  - `$SELECTED_DB_SERVICE`

---

## 💡 Pro Tips

### 1. Quick Database Test
```bash
# From main menu
# Option 5 → View all databases
# Option 6 → Reload if you made changes
```

### 2. Monitor Operations
```bash
# Watch logs in real-time
tail -f logs/oracle_admin_$(date +%Y%m%d).log
```

### 3. Review Reports
```bash
# List recent reports
ls -lht reports/*.html | head -5

# Open in browser
firefox reports/health_check_PRODDB_*.html
```

### 4. Quick Health Check
```bash
# Option 1 → Select DB → Confirm
# Report auto-generated in reports/
```

### 5. Safe Switchover
```bash
# Always review the switchover plan
# Type 'SWITCHOVER' to proceed
# Automatic rollback on failure
```

---

## 🚨 Important Notes

### Before Switchover
- ✅ Verify both databases are accessible
- ✅ Check Data Guard sync status
- ✅ Ensure no active transactions
- ✅ Have rollback plan ready

### Before Flashback
- ✅ Create guaranteed restore point
- ✅ Ensure sufficient flashback space
- ✅ Test restore point first
- ✅ Have backup available

### Regular Maintenance
- 🔄 Review logs weekly
- 🔄 Clean old reports monthly
- 🔄 Test restore points quarterly
- 🔄 Update database list as needed

---

## 📊 Status Indicators

### In Menus
- `✓` = Success / Available
- `✗` = Failed / Error
- `⚠️` = Warning / Attention needed
- `ℹ️` = Information

### In Logs
- `[INFO]` = Normal operation
- `[WARN]` = Warning condition
- `[ERROR]` = Error occurred
- `[DEBUG]` = Debug information

---

## 🔗 Quick Commands

### View Today's Log
```bash
tail -50 logs/oracle_admin_$(date +%Y%m%d).log
```

### Find Recent Reports
```bash
ls -t reports/*.html | head -5
```

### Check Database List
```bash
cat config/database_list.txt | grep -v "^#"
```

### Test All Connections
```bash
# From main menu: Option 5
# Manually:
while read line; do
  [[ $line =~ ^# ]] && continue
  db=$(echo $line | cut -d'|' -f1)
  scan=$(echo $line | cut -d'|' -f2)
  service=$(echo $line | cut -d'|' -f3)
  echo "Testing $db..."
  sqlplus -L sys/pass@$scan/$service as sysdba << EOF
  select 'OK' from dual;
  exit;
EOF
done < config/database_list.txt
```

### Backup Configuration
```bash
tar -czf config_backup_$(date +%Y%m%d).tar.gz config/
```

---

## 📞 Support Information

### Log Files
- Location: `logs/oracle_admin_YYYYMMDD.log`
- Format: `[timestamp] [level] message`
- Rotation: Daily

### Reports
- Location: `reports/`
- Format: HTML with CSS
- Types:
  - `health_check_DBNAME_timestamp.html`
  - `dg_status_DBNAME_timestamp.html`
  - `switchover_DBNAME_timestamp.log`

### Configuration
- Database list: `config/database_list.txt`
- System config: `config/script_config.conf`
- Permissions: 600 for config files

---

## ✅ Deployment Checklist

- [ ] All 6 scripts present
- [ ] Scripts are executable
- [ ] Directories created
- [ ] database_list.txt configured
- [ ] script_config.conf updated
- [ ] Oracle environment set
- [ ] Test connection works
- [ ] Main menu shows databases
- [ ] Health check runs successfully
- [ ] Logs are being created

---

## 🎊 Quick Success Check

Run this test:
```bash
./oracle_rac_admin.sh
```

You should see:
1. ✓ "Successfully loaded X database(s)"
2. ✓ Main menu displays
3. ✓ Databases listed with details
4. ✓ All menu options (1-7, 0) available

If all of the above work → **Deployment Successful!** ✅

---

**Version:** 2.1  
**Date:** November 14, 2025  
**Status:** Production Ready

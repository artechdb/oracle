# Email Functionality Guide
## Oracle RAC Administration Scripts v2.1

---

## 📧 Overview

The Oracle RAC Administration scripts now include **complete email functionality** to automatically send HTML reports after each operation.

### What's Included

✅ **Automatic HTML Email Reports** - Sent after:
- Database Health Checks
- Data Guard Status Checks
- Switchover Operations
- Restore Point Operations

✅ **Email Function** - `send_email()` in functions_common.sh
✅ **Configuration Options** - Enable/disable, recipients, subject prefix
✅ **Multiple Delivery Methods** - sendmail, mail, mailx
✅ **HTML Support** - Beautiful styled HTML emails
✅ **Error Handling** - Graceful fallback if email fails

---

## ⚙️ Configuration

### Required Configuration File

Edit your configuration file (typically `oracle_admin.conf` or `config/script_config.conf`):

```bash
################################################################################
# EMAIL CONFIGURATION
################################################################################

# Enable or disable email notifications
MAIL_ENABLED="YES"              # Set to "NO" to disable all emails

# Email addresses
EMAIL_FROM="oracle_admin@company.com"
EMAIL_RECIPIENTS="dba@company.com,dba_team@company.com"

# Email subject prefix
EMAIL_SUBJECT_PREFIX="[Oracle RAC]"

# Connection timeout (seconds)
CONNECTION_TIMEOUT=30
```

### Configuration Parameters Explained

| Parameter | Required | Description | Example |
|-----------|----------|-------------|---------|
| `MAIL_ENABLED` | Yes | Enable/disable emails | `YES` or `NO` |
| `EMAIL_FROM` | Yes | Sender email address | `oracle@company.com` |
| `EMAIL_RECIPIENTS` | Yes | Comma-separated recipients | `dba1@co.com,dba2@co.com` |
| `EMAIL_SUBJECT_PREFIX` | No | Prefix for email subjects | `[Oracle RAC]` |
| `CONNECTION_TIMEOUT` | No | DB connection timeout | `30` |

---

## 🚀 How It Works

### Automatic Email Flow

```
1. Operation Completes (e.g., Health Check)
   ↓
2. HTML Report Generated
   ↓
3. send_email() Function Called
   ↓
4. Email Configuration Checked
   ↓
5. Mail Command Selected (sendmail/mail/mailx)
   ↓
6. MIME Email Created
   ↓
7. HTML Content Attached
   ↓
8. Email Sent to Recipients
   ↓
9. Success/Failure Logged
```

### Email Function Signature

```bash
send_email "Subject" "/path/to/report.html" "optional@recipients.com"
```

**Parameters:**
1. `$1` - Email subject (will be prefixed with EMAIL_SUBJECT_PREFIX)
2. `$2` - Path to HTML file to send
3. `$3` - Optional recipients (overrides EMAIL_RECIPIENTS from config)

---

## 📝 Usage Examples

### Example 1: Send Health Check Report

```bash
# In your health check function
local report_file="${REPORT_BASE_DIR}/health_check_${db_name}_${timestamp}.html"

# Generate HTML report
{
    generate_html_header "Database Health Check - ${db_name}"
    echo "<h2>Health Check Results</h2>"
    # ... report content ...
    generate_html_footer
} > "$report_file"

# Send email with report
send_email "Database Health Check - ${db_name}" "$report_file"
```

### Example 2: Send Data Guard Status Report

```bash
# In DG status function
local report_file="${REPORT_BASE_DIR}/dg_status_${db_name}_${timestamp}.html"

# Generate report
{
    generate_html_header "Data Guard Status - ${db_name}"
    echo "<h2>Data Guard Configuration</h2>"
    # ... report content ...
    generate_html_footer
} > "$report_file"

# Send email
send_email "Data Guard Status - ${db_name}" "$report_file"
```

### Example 3: Send to Specific Recipients

```bash
# Send to different recipients than configured
send_email "Critical Alert" "/path/to/alert.html" "manager@company.com,oncall@company.com"
```

### Example 4: Test Email Configuration

```bash
# Create test HTML
cat > /tmp/test_email.html << 'EOF'
<!DOCTYPE html>
<html>
<head><title>Test Email</title></head>
<body>
<h1>Test Email</h1>
<p>This is a test email from Oracle RAC Admin script.</p>
<p>If you received this, email configuration is working correctly!</p>
</body>
</html>
EOF

# Send test email
send_email "Test Email" "/tmp/test_email.html"

# Cleanup
rm -f /tmp/test_email.html
```

---

## 🔧 Email Delivery Methods

The `send_email()` function automatically detects and uses the best available method:

### Priority Order

1. **sendmail** (preferred) - Best HTML support
2. **mailx** - Good compatibility
3. **mail** - Basic functionality

### How It Works

```bash
# Function automatically checks for available commands:
if command -v sendmail &> /dev/null; then
    # Use sendmail
elif command -v mailx &> /dev/null; then
    # Use mailx
elif command -v mail &> /dev/null; then
    # Use mail
else
    # Error: No mail command available
fi
```

### Installing Mail Commands

If no mail command is available, install one:

**Oracle Linux / RHEL / CentOS:**
```bash
# Install mailx
sudo yum install mailx -y

# Or install sendmail
sudo yum install sendmail -y
sudo systemctl start sendmail
sudo systemctl enable sendmail
```

**Ubuntu / Debian:**
```bash
# Install mailutils
sudo apt-get install mailutils -y

# Or install sendmail
sudo apt-get install sendmail -y
sudo systemctl start sendmail
```

---

## 📨 Email Format

### MIME Email Structure

The function creates properly formatted MIME emails:

```
From: oracle_admin@company.com
To: dba@company.com
Subject: [Oracle RAC] Database Health Check - PRODDB
MIME-Version: 1.0
Content-Type: text/html; charset="UTF-8"
Content-Transfer-Encoding: 8bit

<!DOCTYPE html>
<html>
...HTML content...
</html>
```

### Email Appearance

Recipients will see:
- **Subject:** `[Oracle RAC] Database Health Check - PRODDB`
- **From:** `oracle_admin@company.com`
- **Content:** Styled HTML report with tables, colors, formatting
- **Professional** Oracle-branded styling

---

## 🐛 Troubleshooting

### Issue: Emails Not Being Sent

**Check 1: Is email enabled?**
```bash
grep MAIL_ENABLED oracle_admin.conf
# Should show: MAIL_ENABLED="YES"
```

**Check 2: Are recipients configured?**
```bash
grep EMAIL_RECIPIENTS oracle_admin.conf
# Should show: EMAIL_RECIPIENTS="email@domain.com"
```

**Check 3: Is mail command available?**
```bash
which mailx || which mail || which sendmail
# Should show path to at least one command
```

**Check 4: Check logs**
```bash
tail -50 logs/oracle_admin_$(date +%Y%m%d).log | grep -i email
# Look for email-related messages
```

### Issue: "Neither mail nor mailx command is available"

**Solution:** Install a mail command
```bash
# Oracle Linux / RHEL
sudo yum install mailx -y

# Test installation
which mailx
```

### Issue: Emails Sent But Not Received

**Possible Causes:**
1. **Mail server not configured** - Check /etc/mail/sendmail.cf
2. **Firewall blocking** - Check port 25
3. **Spam filter** - Check recipient's spam folder
4. **DNS issues** - Check MX records

**Debug Steps:**
```bash
# Test sendmail directly
echo "Test" | sendmail -v your@email.com

# Check mail logs
tail -100 /var/log/maillog

# Check sendmail queue
mailq
```

### Issue: HTML Not Rendering

**Solution:** Ensure proper MIME headers
```bash
# The send_email function handles this automatically
# Check that the HTML file is valid:
cat /path/to/report.html | head -20
# Should start with <!DOCTYPE html>
```

---

## 🔐 Security Considerations

### Email Security Best Practices

1. **Sender Address**
   ```bash
   # Use proper domain email
   EMAIL_FROM="oracle_admin@company.com"
   # NOT: EMAIL_FROM="root@localhost"
   ```

2. **Recipient Validation**
   ```bash
   # Validate email addresses in config
   # Use only company email addresses
   EMAIL_RECIPIENTS="dba@company.com"
   ```

3. **Content Security**
   ```bash
   # Never include passwords in emails
   # Sanitize database names if needed
   # Don't expose sensitive system information
   ```

4. **File Permissions**
   ```bash
   # Protect configuration file
   chmod 600 oracle_admin.conf
   
   # Protect temporary email files
   # (send_email() automatically cleans up)
   ```

---

## 📊 Email Logging

### Log Entries

The send_email function logs all operations:

```
[2025-11-17 10:30:45] [INFO] Sending email: Database Health Check - PRODDB
[2025-11-17 10:30:45] [DEBUG] Using mail command: mailx
[2025-11-17 10:30:45] [DEBUG] Using sendmail for delivery
[2025-11-17 10:30:46] [INFO] Email sent successfully to dba@company.com
```

### Check Email Status

```bash
# View today's email activity
grep -i email logs/oracle_admin_$(date +%Y%m%d).log

# Check for email errors
grep "ERROR.*email\|Failed to send email" logs/oracle_admin_$(date +%Y%m%d).log

# Count emails sent
grep "Email sent successfully" logs/oracle_admin_*.log | wc -l
```

---

## 🎨 Email Templates

### Customizing Email Appearance

The HTML reports use CSS styling defined in `generate_html_header()`:

**Current Styling:**
- Oracle Red theme (#c74634)
- Clean, professional tables
- Color-coded status boxes
- Responsive design

**To Customize:**
Edit the CSS in `functions_common.sh`:
```bash
# Find this section in generate_html_header():
<style>
    body {
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        /* ... customize here ... */
    }
</style>
```

---

## 🧪 Testing Email Configuration

### Quick Test Script

Create a test script:

```bash
#!/bin/bash

# Load configuration
source oracle_admin.conf

# Load functions
source functions_common.sh

# Create test HTML
cat > /tmp/test_email.html << 'EOF'
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Email Configuration Test</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        .box { background: #e7f3fe; border-left: 6px solid #2196F3; padding: 10px; }
    </style>
</head>
<body>
    <h1>Email Configuration Test</h1>
    <div class="box">
        <p><strong>Status:</strong> SUCCESS</p>
        <p>If you received this email, your Oracle RAC Admin email configuration is working correctly!</p>
    </div>
    <p><strong>Test Date:</strong> $(date)</p>
    <p><strong>Sent From:</strong> $(hostname)</p>
</body>
</html>
EOF

# Send test email
echo "Sending test email..."
if send_email "Email Configuration Test" "/tmp/test_email.html"; then
    echo "✓ Test email sent successfully!"
    echo "Check your inbox at: ${EMAIL_RECIPIENTS}"
else
    echo "✗ Failed to send test email"
    echo "Check logs: logs/oracle_admin_$(date +%Y%m%d).log"
fi

# Cleanup
rm -f /tmp/test_email.html
```

Save as `test_email.sh`, then:
```bash
chmod +x test_email.sh
./test_email.sh
```

---

## 📋 Configuration Examples

### Example 1: Basic Configuration

```bash
# oracle_admin.conf
MAIL_ENABLED="YES"
EMAIL_FROM="oracle@company.com"
EMAIL_RECIPIENTS="dba@company.com"
EMAIL_SUBJECT_PREFIX="[Oracle RAC]"
```

### Example 2: Multiple Recipients

```bash
# Send to entire DBA team
EMAIL_RECIPIENTS="dba1@company.com,dba2@company.com,dba3@company.com"
```

### Example 3: Disabled Email

```bash
# Disable emails during maintenance
MAIL_ENABLED="NO"
EMAIL_FROM="oracle@company.com"
EMAIL_RECIPIENTS="dba@company.com"
```

### Example 4: Custom Subject Prefix

```bash
# Use environment-specific prefix
EMAIL_SUBJECT_PREFIX="[PROD-ORACLE]"

# Result: [PROD-ORACLE] Database Health Check - PRODDB
```

---

## ✅ Integration Checklist

Ensure email is properly integrated:

- [ ] `send_email()` function present in functions_common.sh
- [ ] Email configuration added to oracle_admin.conf
- [ ] `MAIL_ENABLED="YES"` in configuration
- [ ] `EMAIL_FROM` configured with valid address
- [ ] `EMAIL_RECIPIENTS` configured with target addresses
- [ ] Mail command installed (mailx/mail/sendmail)
- [ ] Mail command tested manually
- [ ] Test email sent successfully
- [ ] Email calls added after report generation
- [ ] Logs show email activity
- [ ] Recipients receiving emails

---

## 🎯 Quick Reference

### Enable/Disable Email

```bash
# Enable
sed -i 's/MAIL_ENABLED="NO"/MAIL_ENABLED="YES"/' oracle_admin.conf

# Disable
sed -i 's/MAIL_ENABLED="YES"/MAIL_ENABLED="NO"/' oracle_admin.conf
```

### Update Recipients

```bash
# Edit configuration
vi oracle_admin.conf

# Or use sed
sed -i 's/EMAIL_RECIPIENTS=.*/EMAIL_RECIPIENTS="new@email.com"/' oracle_admin.conf
```

### Test Email

```bash
# Quick test
echo "<h1>Test</h1>" > /tmp/test.html
source oracle_admin.conf
source functions_common.sh
send_email "Test" "/tmp/test.html"
```

### Check Email Logs

```bash
# Recent email activity
tail -20 logs/oracle_admin_$(date +%Y%m%d).log | grep -i email

# All email activity
grep -i email logs/oracle_admin_*.log

# Failed emails
grep "ERROR.*email" logs/oracle_admin_*.log
```

---

## 📚 Additional Resources

### Mail Configuration
- sendmail configuration: `/etc/mail/sendmail.cf`
- Mail logs: `/var/log/maillog` or `/var/log/mail.log`
- Mail queue: `mailq` command

### Testing Tools
```bash
# Test email manually
echo "Test" | mail -s "Test Subject" your@email.com

# Check mail queue
mailq

# View mail logs
tail -100 /var/log/maillog

# Test sendmail
echo "Test message" | sendmail -v your@email.com
```

---

## ✨ Summary

The email functionality is **fully integrated** and ready to use:

✅ **Complete** - send_email() function with all features
✅ **Automatic** - Emails sent after each operation
✅ **Configurable** - Enable/disable, recipients, styling
✅ **Robust** - Multiple delivery methods, error handling
✅ **Logged** - All email activity tracked in logs
✅ **Professional** - Beautiful HTML styled reports
✅ **Tested** - Test script provided

**Next Steps:**
1. Configure email settings in oracle_admin.conf
2. Install mail command if needed
3. Run test_email.sh
4. Verify emails received
5. Enjoy automatic report delivery!

---

**Document Version:** 1.0  
**Date:** November 17, 2025  
**Status:** Complete ✅

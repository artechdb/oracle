#!/bin/bash
################################################################################
# Migration Script: Integrate DG Common Functions
# Description: Automates the migration from separate files to integrated
# Usage: ./migrate_to_integrated_common.sh
################################################################################

set -e  # Exit on error

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Script directory
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo -e "${BLUE}╔════════════════════════════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║   Oracle RAC Admin - Integration Migration Script             ║${NC}"
echo -e "${BLUE}║   Integrating functions_dg_common.sh into functions_common.sh  ║${NC}"
echo -e "${BLUE}╚════════════════════════════════════════════════════════════════╝${NC}"
echo ""

################################################################################
# Step 1: Validation
################################################################################
echo -e "${YELLOW}[Step 1/6] Validating environment...${NC}"

# Check if running from correct directory
if [[ ! -f "functions_common.sh" ]]; then
    echo -e "${RED}ERROR: functions_common.sh not found in current directory${NC}"
    echo "Please run this script from your Oracle admin scripts directory"
    exit 1
fi

echo -e "${GREEN}✓ Environment validated${NC}"
echo ""

################################################################################
# Step 2: Create Backups
################################################################################
echo -e "${YELLOW}[Step 2/6] Creating backups...${NC}"

BACKUP_DATE=$(date +%Y%m%d_%H%M%S)
BACKUP_DIR="backup_${BACKUP_DATE}"

mkdir -p "${BACKUP_DIR}"

# Backup all function files
for file in functions_*.sh oracle_rac_admin.sh; do
    if [[ -f "$file" ]]; then
        cp "$file" "${BACKUP_DIR}/"
        echo "  Backed up: $file"
    fi
done

echo -e "${GREEN}✓ Backups created in: ${BACKUP_DIR}${NC}"
echo ""

################################################################################
# Step 3: Check if New File Exists
################################################################################
echo -e "${YELLOW}[Step 3/6] Checking for new integrated file...${NC}"

if [[ ! -f "functions_common.sh.integrated" ]] && [[ ! -f "/tmp/functions_common.sh.new" ]]; then
    echo -e "${YELLOW}⚠ New integrated functions_common.sh not found${NC}"
    echo ""
    echo "Please ensure you have downloaded the new integrated functions_common.sh file"
    echo "and either:"
    echo "  1. Place it as 'functions_common.sh.integrated' in this directory, OR"
    echo "  2. Place it as '/tmp/functions_common.sh.new'"
    echo ""
    echo "Then run this script again."
    exit 1
fi

# Determine which file to use
if [[ -f "functions_common.sh.integrated" ]]; then
    NEW_COMMON_FILE="functions_common.sh.integrated"
else
    NEW_COMMON_FILE="/tmp/functions_common.sh.new"
fi

echo -e "${GREEN}✓ Found new integrated file: ${NEW_COMMON_FILE}${NC}"
echo ""

################################################################################
# Step 4: Update functions_common.sh
################################################################################
echo -e "${YELLOW}[Step 4/6] Deploying new integrated functions_common.sh...${NC}"

# Copy the new integrated file
cp "${NEW_COMMON_FILE}" "functions_common.sh"
chmod 755 "functions_common.sh"

echo -e "${GREEN}✓ Deployed new functions_common.sh${NC}"
echo ""

################################################################################
# Step 5: Update Scripts to Remove Duplicate Source
################################################################################
echo -e "${YELLOW}[Step 5/6] Updating scripts to remove duplicate source statements...${NC}"

# List of files to update
files_to_update=(
    "oracle_rac_admin.sh"
    "functions_db_health.sh"
    "functions_dg_health.sh"
    "functions_dg_switchover.sh"
    "functions_restore_point.sh"
)

for file in "${files_to_update[@]}"; do
    if [[ -f "$file" ]]; then
        # Check if file contains the duplicate source line
        if grep -q 'source.*functions_dg_common.sh' "$file"; then
            echo "  Updating: $file"
            
            # Remove the line sourcing functions_dg_common.sh
            sed -i.bak '/source.*functions_dg_common.sh/d' "$file"
            
            # Also remove any commented versions
            sed -i '/^[[:space:]]*#.*source.*functions_dg_common.sh/d' "$file"
            
            echo -e "    ${GREEN}✓ Removed duplicate source statement${NC}"
        else
            echo "  Skipping: $file (no duplicate source found)"
        fi
    else
        echo "  Skipping: $file (not found)"
    fi
done

echo -e "${GREEN}✓ Scripts updated${NC}"
echo ""

################################################################################
# Step 6: Deprecate Old DG Common File
################################################################################
echo -e "${YELLOW}[Step 6/6] Deprecating old functions_dg_common.sh...${NC}"

if [[ -f "functions_dg_common.sh" ]]; then
    # Move to backup directory with deprecated suffix
    mv "functions_dg_common.sh" "${BACKUP_DIR}/functions_dg_common.sh.deprecated"
    echo -e "${GREEN}✓ Moved functions_dg_common.sh to backup directory${NC}"
else
    echo "  No functions_dg_common.sh found (already removed)"
fi

echo ""

################################################################################
# Summary
################################################################################
echo -e "${BLUE}╔════════════════════════════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║                    MIGRATION COMPLETED                         ║${NC}"
echo -e "${BLUE}╚════════════════════════════════════════════════════════════════╝${NC}"
echo ""
echo -e "${GREEN}✓ Backups created in: ${BACKUP_DIR}${NC}"
echo -e "${GREEN}✓ New integrated functions_common.sh deployed${NC}"
echo -e "${GREEN}✓ Scripts updated (duplicate source removed)${NC}"
echo -e "${GREEN}✓ Old functions_dg_common.sh deprecated${NC}"
echo ""
echo -e "${YELLOW}Next Steps:${NC}"
echo "1. Review the changes in ${BACKUP_DIR}"
echo "2. Test the updated scripts:"
echo "   ./oracle_rac_admin.sh"
echo "3. Run the test checklist:"
echo "   - Database Health Check (option 1)"
echo "   - Data Guard Health Check (option 2)"
echo "   - View logs to verify no errors"
echo ""
echo "4. If everything works, you can remove the backup directory:"
echo "   rm -rf ${BACKUP_DIR}"
echo ""
echo -e "${YELLOW}Rollback (if needed):${NC}"
echo "cp ${BACKUP_DIR}/* ./"
echo ""
echo -e "${GREEN}Migration successful! 🎉${NC}"

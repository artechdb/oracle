# Integration of Data Guard Functions into functions_common.sh

## Overview

The Data Guard common functions from `functions_dg_common.sh` have been successfully integrated into `functions_common.sh`. This consolidation provides a single, unified function library for all Oracle RAC and Data Guard administration tasks.

---

## What Was Integrated

### Original Structure (Before Integration)
```
functions_common.sh        (210 lines) - Common utilities
functions_dg_common.sh     (470 lines) - Data Guard functions
───────────────────────────────────────
Total: 2 files, 680 lines
```

### New Structure (After Integration)
```
functions_common.sh        (680 lines) - All functions unified
───────────────────────────────────────
Total: 1 file, 680 lines
```

---

## Functions Included in Integrated functions_common.sh

### 1. **Logging and Utility Functions** (Lines 1-200)
- `log_message()` - Enhanced logging with colors and audit trail
- `validate_prerequisites()` - Pre-flight checks
- `cleanup_old_files()` - File retention management
- `format_bytes()` - Human-readable byte formatting

### 2. **Database Connection Functions** (Lines 201-350)
- `load_database_list()` - Load database configurations with validation
- `test_db_connection()` - Test connectivity via sqlplus
- `validate_database_connection()` - Validate and exit on failure
- `get_database_role()` - Identify PRIMARY/STANDBY role
- `send_email_report()` - Email report delivery

### 3. **Data Guard Core Functions** (Lines 351-470)
- `get_dg_broker_configuration()` - Get DG Broker config
- `get_primary_database_dgmgrl()` - Identify primary database
- `get_all_standby_databases_dgmgrl()` - List all standbys
- `get_database_connection_from_dgmgrl()` - Extract connection info
- `get_primary_and_standbys_dgmgrl()` - Complete DG topology

### 4. **Data Guard Control Functions** (Lines 471-530)
- `stop_apply_on_standby()` - Stop redo apply
- `start_apply_on_standby()` - Start redo apply

### 5. **Data Guard Status Functions** (Lines 531-620)
- `check_dg_status_dgmgrl()` - Overall DG status
- `check_database_status_dgmgrl()` - Detailed DB status
- `check_standby_lag_dgmgrl()` - Transport/Apply lag
- `get_database_property_dgmgrl()` - Get specific properties

### 6. **Data Guard Validation Functions** (Lines 621-680)
- `validate_dgmgrl_connection()` - Validate DGMGRL connectivity

---

## Benefits of Integration

### ✅ **Simplified Maintenance**
- **Before**: Update 2 files for common functionality
- **After**: Update 1 file - changes apply everywhere

### ✅ **Reduced Complexity**
- **Before**: Source 2 files in each script
- **After**: Source 1 file - simpler dependencies

### ✅ **Easier Testing**
- **Before**: Test 2 separate libraries
- **After**: Test 1 unified library

### ✅ **Better Organization**
- All related functions logically grouped
- Clear section headers for navigation
- Consistent function documentation

---

## How to Use the Integrated File

### In Your Main Scripts

**Old Way (2 files):**
```bash
#!/bin/bash
source "${SCRIPT_DIR}/functions_common.sh"
source "${SCRIPT_DIR}/functions_dg_common.sh"
```

**New Way (1 file):**
```bash
#!/bin/bash
source "${SCRIPT_DIR}/functions_common.sh"
```

### Scripts That Need Updating

Update these files to source only `functions_common.sh`:

1. **oracle_rac_admin.sh** (main script)
2. **functions_db_health.sh** (database health checks)
3. **functions_dg_health.sh** (Data Guard health checks)
4. **functions_dg_switchover.sh** (switchover operations)
5. **functions_restore_point.sh** (restore point management)

---

## Migration Steps

### Step 1: Backup Current Files
```bash
cd /u01/app/oracle/admin/scripts
cp functions_common.sh functions_common.sh.backup_$(date +%Y%m%d)
cp functions_dg_common.sh functions_dg_common.sh.backup_$(date +%Y%m%d)
```

### Step 2: Deploy Integrated File
```bash
# Replace with the new integrated version
cp /path/to/new/functions_common.sh /u01/app/oracle/admin/scripts/
chmod 755 /u01/app/oracle/admin/scripts/functions_common.sh
```

### Step 3: Update Scripts (Remove Duplicate Source)
Edit each script and remove the line:
```bash
source "${SCRIPT_DIR}/functions_dg_common.sh"
```

Keep only:
```bash
source "${SCRIPT_DIR}/functions_common.sh"
```

### Step 4: Remove Old DG Common File (Optional)
```bash
# After verifying everything works
mv functions_dg_common.sh functions_dg_common.sh.deprecated
```

### Step 5: Test Everything
```bash
# Test database health check
./oracle_rac_admin.sh
# Select option 1 (Database Health Check)

# Test Data Guard health check
./oracle_rac_admin.sh
# Select option 2 (Data Guard Health Check)

# Test Data Guard operations
./oracle_rac_admin.sh
# Select option 3 (Data Guard Switchover - TEST ONLY)
```

---

## Function Usage Examples

### Example 1: Database Connection with Validation
```bash
#!/bin/bash
source functions_common.sh

# Load database info
config=$(load_database_list "PRODDB")
if [[ -z "${config}" ]]; then
    echo "Database not found"
    exit 1
fi

IFS='|' read -r db scan service <<< "${config}"

# Validate connection (exits on failure)
validate_database_connection "${db}" "${scan}" "${service}"

echo "Successfully connected to ${db}"
```

### Example 2: Data Guard Operations
```bash
#!/bin/bash
source functions_common.sh

# Get DG configuration
if get_dg_broker_configuration "PRODDB"; then
    echo "DG Config: ${DG_CONFIG_NAME}"
    
    # Identify primary
    get_primary_database_dgmgrl
    echo "Primary: ${PRIMARY_DB_UNIQUE_NAME}"
    
    # Get all standbys
    get_all_standby_databases_dgmgrl
    for standby in "${STANDBY_DBS_ARRAY[@]}"; do
        echo "Standby: ${standby}"
        
        # Check lag
        check_standby_lag_dgmgrl "${standby}"
        echo "  Transport Lag: ${LAG_TRANSPORT}"
        echo "  Apply Lag: ${LAG_APPLY}"
    done
fi
```

### Example 3: Stop/Start Apply
```bash
#!/bin/bash
source functions_common.sh

# Initialize DG connection
get_dg_broker_configuration "PRODDB"

# Stop apply on standby
if stop_apply_on_standby "STANDBY1"; then
    echo "Apply stopped successfully"
    
    # Do maintenance work...
    sleep 5
    
    # Restart apply
    if start_apply_on_standby "STANDBY1"; then
        echo "Apply restarted successfully"
    fi
fi
```

---

## Backward Compatibility

### For Scripts Still Using functions_dg_common.sh

If you have custom scripts that source `functions_dg_common.sh`, you can create a symlink or wrapper:

**Option 1: Symlink**
```bash
ln -s functions_common.sh functions_dg_common.sh
```

**Option 2: Wrapper Script**
```bash
cat > functions_dg_common.sh << 'EOF'
#!/bin/bash
# Compatibility wrapper - all functions now in functions_common.sh
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/functions_common.sh"
EOF
```

---

## Testing Checklist

After integration, verify these operations:

- [ ] Database connectivity validation works
- [ ] Database list loading works (single DB and ALL)
- [ ] Data Guard broker connection works
- [ ] Primary database identification works
- [ ] Standby database identification works
- [ ] Connection info extraction from DGMGRL works
- [ ] Stop/Start apply operations work
- [ ] Lag checking works
- [ ] DG status checking works
- [ ] Email report sending works
- [ ] Log file creation works

---

## Troubleshooting

### Issue: "functions_dg_common.sh not found"
**Solution**: Your scripts are still trying to source the old file
```bash
# Edit each script and remove this line:
source "${SCRIPT_DIR}/functions_dg_common.sh"
```

### Issue: Function not found
**Solution**: Ensure you're sourcing the new integrated functions_common.sh
```bash
# Check the source statement in your script:
source "${SCRIPT_DIR}/functions_common.sh"

# Verify the file contains the function:
grep -n "function_name" functions_common.sh
```

### Issue: DGMGRL connection fails
**Solution**: Initialize the DG configuration first
```bash
# Always call this before using DG functions:
get_dg_broker_configuration "DATABASE_NAME"
```

---

## Summary

| **Aspect** | **Before** | **After** |
|------------|-----------|----------|
| **Files** | 2 (common + dg_common) | 1 (integrated) |
| **Lines** | 680 total | 680 total |
| **Source Statements** | 2 per script | 1 per script |
| **Maintenance** | Update 2 files | Update 1 file |
| **Functions** | 18 functions | 18 functions (unified) |

---

## Version Information

**Integrated File**: functions_common.sh  
**Lines**: 680  
**Functions**: 18 total  
- 5 logging/utility functions
- 5 database connection functions  
- 8 Data Guard functions  

**Status**: ✅ Ready for deployment  
**Date**: 2025-11-10  

---

**All functions consolidated into one powerful library! 🎉**

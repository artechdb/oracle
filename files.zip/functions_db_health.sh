#!/bin/bash
################################################################################
# Oracle 19c Database Health Check Functions
# Description: Functions for performing database health checks
# Version: 2.0 (Integrated)
# Created: 2025-11-02
# Updated: 2025-11-10 - Updated to use integrated functions_common.sh only
################################################################################

# NOTE: This file assumes functions_common.sh has already been sourced
# by the calling script (oracle_rac_admin.sh)

################################################################################
# Function: perform_db_health_check
# Description: Performs health check on a single database
# Parameters: $1 - Database name
#            $2 - SCAN address
#            $3 - Service name
################################################################################
perform_db_health_check() {
    local db_name=$1
    local scan=$2
    local service=$3
    
    log_message "INFO" "Starting health check for database: ${db_name}"
    
    # Validate database connection first
    validate_database_connection "${db_name}" "${scan}" "${service}"
    
    # Generate report file name
    local report_file="${REPORT_BASE_DIR}/${db_name}_health_check_$(date '+%Y%m%d_%H%M%S').html"
    
    # Create report directory if it doesn't exist
    mkdir -p "${REPORT_BASE_DIR}"
    
    log_message "INFO" "Generating health check report: ${report_file}"
    
    # Generate HTML report
    generate_db_health_report "${db_name}" "${scan}" "${service}" "${report_file}"
    
    if [[ $? -eq 0 ]]; then
        log_message "INFO" "Health check report generated successfully"
        echo "Report saved to: ${report_file}"
        
        # Send email if configured
        if [[ "${SEND_EMAIL}" == "YES" ]]; then
            send_email_report "Database Health Check - ${db_name}" "${report_file}" "${EMAIL_RECIPIENTS}"
        fi
    else
        log_message "ERROR" "Failed to generate health check report"
        return 1
    fi
    
    return 0
}

################################################################################
# Function: perform_db_health_check_all
# Description: Performs health check on all databases
################################################################################
perform_db_health_check_all() {
    log_message "INFO" "Starting health check for all databases"
    
    local all_dbs=$(load_database_list "ALL")
    
    if [[ -z "${all_dbs}" ]]; then
        log_message "ERROR" "No databases found"
        echo "ERROR: No databases configured"
        return 1
    fi
    
    while IFS= read -r db_line; do
        IFS='|' read -r db scan service <<< "${db_line}"
        
        echo ""
        echo "Processing database: ${db}"
        echo "-------------------------------------------------------------------"
        
        perform_db_health_check "${db}" "${scan}" "${service}"
        
        echo "-------------------------------------------------------------------"
    done <<< "${all_dbs}"
    
    log_message "INFO" "Completed health check for all databases"
    return 0
}

################################################################################
# Function: generate_db_health_report
# Description: Generates HTML health check report
# Parameters: $1 - Database name
#            $2 - SCAN address
#            $3 - Service name
#            $4 - Output file path
################################################################################
generate_db_health_report() {
    local db_name=$1
    local scan=$2
    local service=$3
    local output_file=$4
    
    local connect_string="${SYS_USER}/${SYS_PASSWORD}@${scan}/${service} as sysdba"
    
    # Start HTML report
    cat > "${output_file}" << 'EOF'
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Database Health Check Report</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            background-color: #f5f5f5;
        }
        .header {
            background-color: #0066cc;
            color: white;
            padding: 20px;
            border-radius: 5px;
            margin-bottom: 20px;
        }
        .section {
            background-color: white;
            padding: 15px;
            margin-bottom: 15px;
            border-radius: 5px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .section-title {
            font-size: 18px;
            font-weight: bold;
            color: #0066cc;
            margin-bottom: 10px;
            border-bottom: 2px solid #0066cc;
            padding-bottom: 5px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
        }
        th {
            background-color: #0066cc;
            color: white;
            padding: 10px;
            text-align: left;
        }
        td {
            padding: 8px;
            border-bottom: 1px solid #ddd;
        }
        tr:hover {
            background-color: #f0f0f0;
        }
        .status-ok {
            color: green;
            font-weight: bold;
        }
        .status-warning {
            color: orange;
            font-weight: bold;
        }
        .status-critical {
            color: red;
            font-weight: bold;
        }
        .footer {
            text-align: center;
            padding: 20px;
            color: #666;
            font-size: 12px;
        }
    </style>
</head>
<body>
EOF
    
    # Add header
    cat >> "${output_file}" << EOF
    <div class="header">
        <h1>Database Health Check Report</h1>
        <p>Database: ${db_name}</p>
        <p>SCAN: ${scan}</p>
        <p>Service: ${service}</p>
        <p>Generated: $(date '+%Y-%m-%d %H:%M:%S')</p>
    </div>
EOF
    
    # Database Instance Information
    cat >> "${output_file}" << 'EOF'
    <div class="section">
        <div class="section-title">Database Instance Information</div>
        <table>
            <tr><th>Parameter</th><th>Value</th></tr>
EOF
    
    ${ORACLE_HOME}/bin/sqlplus -S /nolog << EOSQL >> "${output_file}"
connect ${connect_string}
set pagesize 0 feedback off heading off markup html on
select '<tr><td>Instance Name</td><td>' || instance_name || '</td></tr>' from v\$instance;
select '<tr><td>Host Name</td><td>' || host_name || '</td></tr>' from v\$instance;
select '<tr><td>Version</td><td>' || version || '</td></tr>' from v\$instance;
select '<tr><td>Startup Time</td><td>' || to_char(startup_time, 'YYYY-MM-DD HH24:MI:SS') || '</td></tr>' from v\$instance;
select '<tr><td>Status</td><td>' || status || '</td></tr>' from v\$instance;
select '<tr><td>Database Role</td><td>' || database_role || '</td></tr>' from v\$database;
select '<tr><td>Open Mode</td><td>' || open_mode || '</td></tr>' from v\$database;
select '<tr><td>Log Mode</td><td>' || log_mode || '</td></tr>' from v\$database;
exit;
EOSQL
    
    cat >> "${output_file}" << 'EOF'
        </table>
    </div>
EOF
    
    # Tablespace Usage
    cat >> "${output_file}" << 'EOF'
    <div class="section">
        <div class="section-title">Tablespace Usage</div>
        <table>
            <tr>
                <th>Tablespace Name</th>
                <th>Size (GB)</th>
                <th>Used (GB)</th>
                <th>Free (GB)</th>
                <th>% Used</th>
                <th>Status</th>
            </tr>
EOF
    
    ${ORACLE_HOME}/bin/sqlplus -S /nolog << EOSQL >> "${output_file}"
connect ${connect_string}
set pagesize 0 feedback off heading off markup html on
select 
    '<tr><td>' || tablespace_name || '</td>' ||
    '<td>' || round(total_gb, 2) || '</td>' ||
    '<td>' || round(used_gb, 2) || '</td>' ||
    '<td>' || round(free_gb, 2) || '</td>' ||
    '<td>' || round(pct_used, 2) || '</td>' ||
    '<td class="' || 
        case 
            when pct_used >= 90 then 'status-critical'
            when pct_used >= 80 then 'status-warning'
            else 'status-ok'
        end || '">' ||
        case 
            when pct_used >= 90 then 'CRITICAL'
            when pct_used >= 80 then 'WARNING'
            else 'OK'
        end || '</td></tr>'
from (
    select 
        a.tablespace_name,
        round(a.bytes/1024/1024/1024, 2) as total_gb,
        round(nvl(b.bytes,0)/1024/1024/1024, 2) as used_gb,
        round((a.bytes - nvl(b.bytes,0))/1024/1024/1024, 2) as free_gb,
        round(nvl(b.bytes,0)/a.bytes * 100, 2) as pct_used
    from 
        (select tablespace_name, sum(bytes) bytes 
         from dba_data_files group by tablespace_name) a,
        (select tablespace_name, sum(bytes) bytes 
         from dba_segments group by tablespace_name) b
    where a.tablespace_name = b.tablespace_name(+)
    order by pct_used desc
);
exit;
EOSQL
    
    cat >> "${output_file}" << 'EOF'
        </table>
    </div>
EOF
    
    # Invalid Objects
    cat >> "${output_file}" << 'EOF'
    <div class="section">
        <div class="section-title">Invalid Objects</div>
        <table>
            <tr>
                <th>Owner</th>
                <th>Object Name</th>
                <th>Object Type</th>
                <th>Status</th>
            </tr>
EOF
    
    ${ORACLE_HOME}/bin/sqlplus -S /nolog << EOSQL >> "${output_file}"
connect ${connect_string}
set pagesize 0 feedback off heading off markup html on
select 
    '<tr><td>' || owner || '</td>' ||
    '<td>' || object_name || '</td>' ||
    '<td>' || object_type || '</td>' ||
    '<td class="status-warning">' || status || '</td></tr>'
from dba_objects
where status = 'INVALID'
and owner not in ('SYS','SYSTEM','PUBLIC')
order by owner, object_type, object_name;
exit;
EOSQL
    
    cat >> "${output_file}" << 'EOF'
        </table>
    </div>
EOF
    
    # Active Sessions
    cat >> "${output_file}" << 'EOF'
    <div class="section">
        <div class="section-title">Active Sessions</div>
        <table>
            <tr>
                <th>Username</th>
                <th>SID</th>
                <th>Serial#</th>
                <th>Status</th>
                <th>Machine</th>
                <th>Program</th>
            </tr>
EOF
    
    ${ORACLE_HOME}/bin/sqlplus -S /nolog << EOSQL >> "${output_file}"
connect ${connect_string}
set pagesize 0 feedback off heading off markup html on
select 
    '<tr><td>' || username || '</td>' ||
    '<td>' || sid || '</td>' ||
    '<td>' || serial# || '</td>' ||
    '<td>' || status || '</td>' ||
    '<td>' || machine || '</td>' ||
    '<td>' || program || '</td></tr>'
from v\$session
where username is not null
and status = 'ACTIVE'
order by username;
exit;
EOSQL
    
    cat >> "${output_file}" << 'EOF'
        </table>
    </div>
EOF
    
    # Close HTML
    cat >> "${output_file}" << 'EOF'
    <div class="footer">
        <p>Oracle 19c RAC Database Administration - Health Check Report</p>
    </div>
</body>
</html>
EOF
    
    log_message "INFO" "HTML report generated: ${output_file}"
    return 0
}

################################################################################
# End of functions_db_health.sh
################################################################################

#!/bin/bash
################################################################################
# Oracle 19c Data Guard Health Check Functions
# Description: Functions for performing Data Guard health checks
# Version: 2.0 (Integrated)
# Created: 2025-11-02
# Updated: 2025-11-10 - Removed duplicate functions (now in functions_common.sh)
################################################################################

# NOTE: This file assumes functions_common.sh has already been sourced
# All DG core functions (get_dg_broker_configuration, get_primary_database_dgmgrl,
# etc.) are now in functions_common.sh

################################################################################
# Function: perform_dg_health_check
# Description: Performs Data Guard health check
# Parameters: $1 - Database name (will auto-detect primary)
################################################################################
perform_dg_health_check() {
    local db_name=$1
    
    log_message "INFO" "Starting Data Guard health check for: ${db_name}"
    
    # Get DG Broker configuration
    if ! get_dg_broker_configuration "${db_name}"; then
        log_message "ERROR" "Failed to get DG Broker configuration"
        echo "ERROR: Not part of Data Guard configuration or DGMGRL connection failed"
        return 1
    fi
    
    # Get primary database
    if ! get_primary_database_dgmgrl; then
        log_message "ERROR" "Failed to identify primary database"
        return 1
    fi
    
    # Get all standby databases
    if ! get_all_standby_databases_dgmgrl; then
        log_message "ERROR" "Failed to get standby databases"
        return 1
    fi
    
    # Generate report
    local report_file="${REPORT_BASE_DIR}/${DG_CONFIG_NAME}_dg_health_$(date '+%Y%m%d_%H%M%S').html"
    mkdir -p "${REPORT_BASE_DIR}"
    
    log_message "INFO" "Generating DG health report: ${report_file}"
    
    generate_dg_health_report "${report_file}"
    
    if [[ $? -eq 0 ]]; then
        log_message "INFO" "DG health check report generated successfully"
        echo "Report saved to: ${report_file}"
        
        # Send email if configured
        if [[ "${SEND_EMAIL}" == "YES" ]]; then
            send_email_report "Data Guard Health Check - ${DG_CONFIG_NAME}" "${report_file}" "${EMAIL_RECIPIENTS}"
        fi
    else
        log_message "ERROR" "Failed to generate DG health check report"
        return 1
    fi
    
    return 0
}

################################################################################
# Function: perform_dg_health_check_all
# Description: Performs Data Guard health check on all configured databases
################################################################################
perform_dg_health_check_all() {
    log_message "INFO" "Starting Data Guard health check for all databases"
    
    local all_dbs=$(load_database_list "ALL")
    
    if [[ -z "${all_dbs}" ]]; then
        log_message "ERROR" "No databases found"
        echo "ERROR: No databases configured"
        return 1
    fi
    
    local processed_configs=""
    
    while IFS= read -r db_line; do
        IFS='|' read -r db scan service <<< "${db_line}"
        
        # Try to get DG configuration for this database
        if get_dg_broker_configuration "${db}" 2>/dev/null; then
            # Check if we've already processed this DG configuration
            if echo "${processed_configs}" | grep -q "${DG_CONFIG_NAME}"; then
                log_message "INFO" "Already processed DG config: ${DG_CONFIG_NAME}"
                continue
            fi
            
            echo ""
            echo "Processing Data Guard configuration: ${DG_CONFIG_NAME}"
            echo "-------------------------------------------------------------------"
            
            perform_dg_health_check "${db}"
            
            # Mark this configuration as processed
            processed_configs="${processed_configs} ${DG_CONFIG_NAME}"
            
            echo "-------------------------------------------------------------------"
        else
            log_message "INFO" "Database ${db} is not part of a DG configuration, skipping"
        fi
    done <<< "${all_dbs}"
    
    log_message "INFO" "Completed DG health check for all databases"
    return 0
}

################################################################################
# Function: generate_dg_health_report
# Description: Generates HTML Data Guard health check report
# Parameters: $1 - Output file path
################################################################################
generate_dg_health_report() {
    local output_file=$1
    
    # Start HTML report
    cat > "${output_file}" << 'EOF'
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Data Guard Health Check Report</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            background-color: #f5f5f5;
        }
        .header {
            background-color: #0066cc;
            color: white;
            padding: 20px;
            border-radius: 5px;
            margin-bottom: 20px;
        }
        .section {
            background-color: white;
            padding: 15px;
            margin-bottom: 15px;
            border-radius: 5px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .section-title {
            font-size: 18px;
            font-weight: bold;
            color: #0066cc;
            margin-bottom: 10px;
            border-bottom: 2px solid #0066cc;
            padding-bottom: 5px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
        }
        th {
            background-color: #0066cc;
            color: white;
            padding: 10px;
            text-align: left;
        }
        td {
            padding: 8px;
            border-bottom: 1px solid #ddd;
        }
        tr:hover {
            background-color: #f0f0f0;
        }
        .status-ok {
            color: green;
            font-weight: bold;
        }
        .status-warning {
            color: orange;
            font-weight: bold;
        }
        .status-critical {
            color: red;
            font-weight: bold;
        }
        .status-success {
            color: green;
            font-weight: bold;
        }
        .info-box {
            background-color: #e6f3ff;
            border-left: 4px solid #0066cc;
            padding: 10px;
            margin: 10px 0;
        }
        .footer {
            text-align: center;
            padding: 20px;
            color: #666;
            font-size: 12px;
        }
        pre {
            background-color: #f4f4f4;
            padding: 10px;
            border-radius: 3px;
            overflow-x: auto;
        }
    </style>
</head>
<body>
EOF
    
    # Add header
    cat >> "${output_file}" << EOF
    <div class="header">
        <h1>Data Guard Health Check Report</h1>
        <p>Configuration: ${DG_CONFIG_NAME}</p>
        <p>Generated: $(date '+%Y-%m-%d %H:%M:%S')</p>
    </div>
EOF
    
    # Overall DG Status
    check_dg_status_dgmgrl
    
    cat >> "${output_file}" << EOF
    <div class="section">
        <div class="section-title">Data Guard Configuration Status</div>
        <div class="info-box">
            <strong>Overall Status:</strong> <span class="status-${DG_OVERALL_STATUS,,}">${DG_OVERALL_STATUS}</span>
        </div>
        <pre>${DG_STATUS_OUTPUT}</pre>
    </div>
EOF
    
    # Primary Database Details
    cat >> "${output_file}" << EOF
    <div class="section">
        <div class="section-title">Primary Database: ${PRIMARY_DB_UNIQUE_NAME}</div>
EOF
    
    check_database_status_dgmgrl "${PRIMARY_DB_UNIQUE_NAME}"
    
    cat >> "${output_file}" << EOF
        <pre>${DB_STATUS_OUTPUT}</pre>
    </div>
EOF
    
    # Standby Databases Details
    if [[ ${#STANDBY_DBS_ARRAY[@]} -gt 0 ]]; then
        cat >> "${output_file}" << 'EOF'
    <div class="section">
        <div class="section-title">Standby Databases</div>
        <table>
            <tr>
                <th>Database Name</th>
                <th>Transport Lag</th>
                <th>Apply Lag</th>
                <th>Status</th>
            </tr>
EOF
        
        for standby in "${STANDBY_DBS_ARRAY[@]}"; do
            check_standby_lag_dgmgrl "${standby}"
            
            # Determine status class based on lag
            local status_class="status-ok"
            if [[ "${LAG_APPLY}" != "0 seconds" ]] && [[ "${LAG_APPLY}" != "Unknown" ]]; then
                status_class="status-warning"
            fi
            
            cat >> "${output_file}" << EOF
            <tr>
                <td>${standby}</td>
                <td>${LAG_TRANSPORT}</td>
                <td>${LAG_APPLY}</td>
                <td class="${status_class}">
EOF
            
            if [[ "${LAG_APPLY}" == "0 seconds" ]]; then
                echo "                    OK" >> "${output_file}"
            elif [[ "${LAG_APPLY}" == "Unknown" ]]; then
                echo "                    UNKNOWN" >> "${output_file}"
            else
                echo "                    LAG DETECTED" >> "${output_file}"
            fi
            
            cat >> "${output_file}" << 'EOF'
                </td>
            </tr>
EOF
        done
        
        cat >> "${output_file}" << 'EOF'
        </table>
    </div>
EOF
        
        # Detailed status for each standby
        for standby in "${STANDBY_DBS_ARRAY[@]}"; do
            check_database_status_dgmgrl "${standby}"
            
            cat >> "${output_file}" << EOF
    <div class="section">
        <div class="section-title">Standby Database Details: ${standby}</div>
        <pre>${DB_STATUS_OUTPUT}</pre>
    </div>
EOF
        done
    else
        cat >> "${output_file}" << 'EOF'
    <div class="section">
        <div class="section-title">Standby Databases</div>
        <p>No standby databases found in configuration</p>
    </div>
EOF
    fi
    
    # Switchover Readiness Check
    cat >> "${output_file}" << 'EOF'
    <div class="section">
        <div class="section-title">Switchover Readiness</div>
EOF
    
    check_switchover_readiness >> "${output_file}"
    
    cat >> "${output_file}" << 'EOF'
    </div>
EOF
    
    # Close HTML
    cat >> "${output_file}" << 'EOF'
    <div class="footer">
        <p>Oracle 19c RAC Database Administration - Data Guard Health Check Report</p>
    </div>
</body>
</html>
EOF
    
    log_message "INFO" "DG health report generated: ${output_file}"
    return 0
}

################################################################################
# Function: check_switchover_readiness
# Description: Checks if configuration is ready for switchover
################################################################################
check_switchover_readiness() {
    log_message "INFO" "Checking switchover readiness"
    
    local issues_found=0
    
    echo "<div class='info-box'>"
    echo "<h4>Switchover Readiness Assessment</h4>"
    
    # Check if configuration status is SUCCESS
    if [[ "${DG_OVERALL_STATUS}" != "SUCCESS" ]]; then
        echo "<p class='status-critical'>✗ Configuration status is ${DG_OVERALL_STATUS} (should be SUCCESS)</p>"
        ((issues_found++))
    else
        echo "<p class='status-ok'>✓ Configuration status is SUCCESS</p>"
    fi
    
    # Check each standby for lag
    if [[ ${#STANDBY_DBS_ARRAY[@]} -gt 0 ]]; then
        for standby in "${STANDBY_DBS_ARRAY[@]}"; do
            check_standby_lag_dgmgrl "${standby}"
            
            if [[ "${LAG_APPLY}" == "0 seconds" ]]; then
                echo "<p class='status-ok'>✓ Standby ${standby} has no apply lag</p>"
            elif [[ "${LAG_APPLY}" == "Unknown" ]]; then
                echo "<p class='status-warning'>⚠ Standby ${standby} lag is unknown</p>"
                ((issues_found++))
            else
                echo "<p class='status-warning'>⚠ Standby ${standby} has apply lag: ${LAG_APPLY}</p>"
                ((issues_found++))
            fi
            
            if [[ "${LAG_TRANSPORT}" == "0 seconds" ]]; then
                echo "<p class='status-ok'>✓ Standby ${standby} has no transport lag</p>"
            elif [[ "${LAG_TRANSPORT}" == "Unknown" ]]; then
                echo "<p class='status-warning'>⚠ Standby ${standby} transport lag is unknown</p>"
            else
                echo "<p class='status-warning'>⚠ Standby ${standby} has transport lag: ${LAG_TRANSPORT}</p>"
            fi
        done
    fi
    
    # Overall assessment
    echo "<hr>"
    if [[ ${issues_found} -eq 0 ]]; then
        echo "<p class='status-success'><strong>✓ Configuration is ready for switchover</strong></p>"
    else
        echo "<p class='status-warning'><strong>⚠ ${issues_found} issue(s) found - resolve before attempting switchover</strong></p>"
    fi
    
    echo "</div>"
}

################################################################################
# End of functions_dg_health.sh
################################################################################
